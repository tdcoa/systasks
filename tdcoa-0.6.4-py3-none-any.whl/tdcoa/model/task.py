"TDCOA Task types"
from __future__ import annotations

import csv
import shutil
import subprocess
import sys
from dataclasses import field
from enum import Enum
from logging import getLogger
from pathlib import Path
from string import whitespace
from typing import Any, Callable, ClassVar, Dict, List, Optional, Type, Union

from pydantic import ValidationError, root_validator
from pydantic.dataclasses import dataclass
from teradatasql import OperationalError

from ..excp import InvalidTasklist, SQLExecError
from ..pptx import replace_placeholders
from ..util import load_yaml
from .tdsys import TDConn

FFinder = Callable[[Path], Path]
logger = getLogger(__name__)
tags: Dict[str, Type[Task]] = {}
Loader = Callable[[Union[Path, str]], str]


class ConnectTarget(str, Enum):
	"Teradata connection target"
	source = "source"
	transcend = "transcend"


def locate_file(file: Path, *dirs: Path) -> Path:
	"locate file by searching the directories in order"
	for d in dirs:
		if (d / file).exists():
			return d / file
	raise FileNotFoundError(str(file))


@dataclass
class Task:
	"Base class for Tasks"
	tag: ClassVar[str] = '?'

	name: str
	inpdir: Path
	loader: Optional[Loader]
	connect: Optional[ConnectTarget]

	def __str__(self) -> str:
		return self.name

	def run(self, conn: TDConn, outdir: Path) -> None:
		"Run task"
		raise NotImplementedError

	@classmethod
	def __init_subclass__(cls, **_: Any) -> None:
		tags[cls.tag] = cls


@dataclass
class SQLTask(Task):
	"SQL runner"
	tag: ClassVar[str] = 'execute'

	sql: Optional[str] = None
	sqlfile: Optional[Path] = None

	@root_validator
	def xor(cls: Type[SQLTask], values: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore
		"validate exactly one option has been specified"
		sql, sqlfile = values.get('sql'), values.get('sqlfile')
		if sql is None and sqlfile is None:
			raise ValueError("at least one of 'sql' or 'sqlfile' must be specified")
		if sql is not None and sqlfile is not None:
			raise ValueError("only one of 'sql' or 'sqlfile' can be specified")

		return values

	def _post_exec(self, csr, outdir: Path) -> None:
		"processing after SQL execution"

	def getsql(self) -> str:
		"get SQL text from either sqlfile or the sql"
		if self.sqlfile:
			sql = (self.inpdir / self.sqlfile).read_text().rstrip(whitespace + ";")
			if self.loader is not None:
				sql = self.loader(sql)
			return sql

		return self.sql.rstrip(whitespace + ";")

	def run(self, conn: TDConn, outdir: Path) -> None:
		with conn.cursor() as csr:
			sql = self.getsql()
			try:
				csr.execute(sql)
				err = None
			except OperationalError as e:
				err = e

			if err is not None:
				raise SQLExecError(err, sql)

			self._post_exec(csr, outdir)


@dataclass
class ExportTask(SQLTask):
	"export SQL query data to a CSV file"
	tag: ClassVar[str] = 'export'

	file: Path = Path('output.csv')

	def _post_exec(self, csr, outdir: Path) -> None:
		with (outdir / self.file).open('w', newline='') as fh:
			fw = csv.writer(fh, quoting=csv.QUOTE_MINIMAL)
			fw.writerow(d[0] for d in csr.description)  # write column headers
			fw.writerows(csr)
		logger.debug("Export: File=%s, rows=%d", str(outdir / self.file), csr.rowcount)


@dataclass
class ImportTask(Task):
	"import a CSV file into a table. Table column names must match the CSV header row titles"
	tag: ClassVar[str] = 'import'

	file: Path
	table: str

	def run(self, conn: TDConn, outdir: Path) -> None:
		file = locate_file(self.file, outdir, self.inpdir)
		with file.open(newline='') as fh:
			fr = csv.reader(fh)
			try:
				columns = next(fr)  # the header row
			except StopIteration:  # empty file
				return
			rows = list(fr)
			if rows:
				with conn.cursor() as csr:

					def quote(c: str) -> str:
						"quote SQL identifier"
						return '"' + c.replace('"', '""') + '"'

					sql = f"INSERT INTO {self.table}({','.join(map(quote, columns))}) VALUES({','.join(['?'] * len(columns))})"
					try:
						csr.executemany(sql, rows)
						err = None
					except OperationalError as e:
						err = e

					if err is not None:
						raise SQLExecError(err, sql)

					logger.debug("Import: Table=%s, file=%s, read=%d", self.table, str(file), len(rows))


@dataclass
class CopyTask(Task):
	"copy files to output directory for processing"
	tag: ClassVar[str] = 'copy'

	files: List[Path] = field(default_factory=list)

	def run(self, conn: TDConn, outdir: Path) -> None:
		for f in self.files:
			shutil.copyfile(self.inpdir / f, outdir / f.name)


@dataclass
class CallTask(Task):
	"call a stored-procedure"
	tag: ClassVar[str] = 'call'

	proc: str
	params: List[Any] = field(default_factory=list)

	def run(self, conn: TDConn, outdir: Path) -> None:
		with conn.cursor() as csr:
			sql = f"CALL {self.proc}()"
			try:
				csr.callproc(self.proc, self.params)
				err = None
			except OperationalError as e:
				err = e

			if err is not None:
				raise SQLExecError(err, sql)


@dataclass
class ChartTask(Task):
	"Run a (python) command to create a chart as an image"
	tag: ClassVar[str] = 'chart'

	command: str
	params: List[str] = field(default_factory=list)

	def run(self, conn: TDConn, outdir: Path) -> None:
		cmd = [sys.executable, str(self.inpdir / Path(self.command))] if self.command.endswith('.py') else [self.command]
		subprocess.run(cmd + self.params, cwd=outdir, check=True)


@dataclass
class ScriptTask(Task):
	"Run a (python) command to create a chart as an image"
	tag: ClassVar[str] = 'script'

	command: str
	params: List[str] = field(default_factory=list)

	def run(self, conn: TDConn, outdir: Path) -> None:
		cmd = [sys.executable, str(self.inpdir / Path(self.command))] if self.command.endswith('.py') else [self.command]
		subprocess.run(cmd + self.params, cwd=outdir, check=True)


@dataclass
class PPTTask(Task):
	"Create a PowerPoint presentation from a template-file"
	tag: ClassVar[str] = 'ppt'

	file: Path

	def run(self, conn: TDConn, outdir: Path) -> None:
		shutil.copyfile(self.inpdir / self.file, outdir / self.file.name)
		replace_placeholders(outdir / self.file.name, datapath=outdir)


@dataclass
class TaskList:
	"An ordered list of tasks"
	name: str
	description: Optional[str] = None
	version: Optional[str] = None
	tasks: List[Task] = field(default_factory=list)


def load_tasklist(tldef: Path, file_loader: Optional[Loader] = None) -> TaskList:
	"load tasklist from inp's content, after running through transformer if supplied"
	text = tldef.read_text() if file_loader is None else file_loader(tldef.read_text())
	doc = load_yaml(text)

	if 'tasks' not in doc:
		raise InvalidTasklist(tldef.stem, "Missing 'tasks' attribute")

	tasks = doc.pop('tasks')
	if not isinstance(tasks, list):
		raise InvalidTasklist(tldef.stem, f"'tasks' must be a 'list', but found '{type(tasks).__name__}")

	tl = TaskList(**{**doc, 'name': tldef.stem})
	for e, t in enumerate(tasks, start=1):
		if not isinstance(t, dict):
			raise InvalidTasklist(tldef.stem, f"Task definition must be of type 'dict', but found '{type(t).__name__}'", e)

		logger.debug("Task# %d, dictionary: %s", e, str(t))
		cls = next((cls for tag, cls in tags.items() if tag in t), None)
		if cls is None:
			raise InvalidTasklist(tldef.stem, "Unknown task type", e)

		a = t.pop(cls.tag)
		if not isinstance(a, dict):
			raise InvalidTasklist(tldef.stem, f"Task attributes must be of type 'dict', but found '{type(a).__name__}'", e)

		v: Dict[str, Any] = {**{"connect": None, "inpdir": tldef.parent, "loader": file_loader}, **t, **a}
		logger.debug("Instantiating class %s with values %s", cls.__name__, str(v))
		try:
			task = cls(**v)
			tl.tasks.append(task)
			msg = None
		except TypeError as err:
			msg = str(err)
		except ValidationError as err:
			msg = str(err)
		if msg:
			raise InvalidTasklist(tldef.stem, msg, e)

	return tl
