"application config model"
from __future__ import annotations

import logging
import os
import tempfile
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from shutil import rmtree
from typing import Any, Dict
from zipfile import ZipFile

import requests

logger = logging.getLogger(__name__)


def github_api(url: str) -> requests.Response:
	"checked github API request"
	r = requests.get(url, headers={"Accept": "application/vnd.github.v3+json"}, verify=('TDCOA_NOVERIFY' not in os.environ))
	if r.status_code != 200:
		raise RuntimeError(f"Github API status: {r.status_code}, URL: {url}")

	return r


@dataclass
class GithubRelease:
	"Github release type and its operations"
	repo: str
	artifact: str

	@cached_property
	def _release(self) -> Dict[str, Any]:
		r = github_api(f"https://api.github.com/repos/{self.repo}/releases/latest").json()
		logger.debug("Repo: %s, release info: %s", self.repo, r)
		return r

	@cached_property
	def release_url(self) -> str:
		asset_url = next((asset["url"] for asset in self._release['assets'] if asset["name"] == self.artifact), None)
		if asset_url is None:
			raise FileNotFoundError(f"No assets with {self.artifact} were found for release: {self.version}")

		return github_api(asset_url).json()['browser_download_url']

	@property
	def version(self) -> str:
		"latest release name"
		return self._release['name']

	def download_to(self, target: Path) -> None:
		"empty the target directory, download the latest release and extract the zip file contents into it"
		r = github_api(self.release_url)

		with tempfile.TemporaryDirectory() as tempdir:
			zipfile = Path(str(tempdir)) / self.artifact

			with open(zipfile, "wb") as fh:
				fh.write(r.content)

			with ZipFile(zipfile) as z:
				logger.debug("Extracting github filesets to: '%s'", target)
				rmtree(target)
				z.extractall(target)
