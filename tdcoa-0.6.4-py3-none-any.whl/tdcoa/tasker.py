"Task runner"
import json
from csv import reader, writer
from dataclasses import dataclass, field
from enum import Enum
from itertools import dropwhile, groupby
from logging import getLogger
from pathlib import Path
from typing import Callable, Iterable, List, Optional, Tuple
from zipfile import ZipFile

from . import model as M
from .excp import NoFileToConvert
from .template import make_renderer
from .util import TRANSCEND, strip_pfx, userdirs

logger = getLogger(__name__)


class NotConnected(Exception):
	"Signal when Teradata connection isn't available"


class Connect(str, Enum):
	"Connection disposition for source system"
	Yes = "yes"
	No = "no"
	Assist = "assist"  # assume ran externally in assisted-run mode


@dataclass
class TaskListRunner:
	"A Tasklist run-time instance"
	tasklist: M.TaskList
	srcsys: M.TDSys
	outdir: Path
	conn_src: Connect = Connect.No
	conn_dest: bool = False
	verbose: bool = False
	src_conn: Optional[M.TDConn] = field(default=None, init=False)
	dest_conn: Optional[M.TDConn] = field(default=None, init=False)

	@property
	def chkpt_file(self) -> Path:
		"checkpoint file path"
		return self.outdir / f".restart-{self.tasklist.name}.json"

	@property
	def chkpt_step(self) -> Optional[int]:
		"step # if this is a restart else None"
		if self.chkpt_file.exists():
			with self.chkpt_file.open() as f:
				return json.load(f)["last_tasknum"]
		else:
			return None

	@chkpt_step.setter
	def chkpt_step(self, step_num: int) -> None:
		"restart step"
		with self.chkpt_file.open('w') as f:
			json.dump(dict(tasklist=self.tasklist.name, srcsys=self.srcsys.name, last_tasknum=step_num), f)

	def get_conn(self, tgt: Optional[M.ConnectTarget]) -> Tuple[M.TDConn, bool]:
		"return teradata connection and accept mode indicator"
		if tgt is M.ConnectTarget.source:
			if self.conn_src is Connect.Assist:
				return (None, True)
			if self.conn_src is Connect.No:
				raise NotConnected("Source System")
			if self.src_conn is None:
				self.src_conn = self.srcsys.connect()
			return (self.src_conn, False)

		elif tgt is M.ConnectTarget.transcend:
			if self.dest_conn is None:
				if not self.conn_dest:
					raise NotConnected("Transcend")
				self.dest_conn = M.load_tdsys(userdirs.tdsys / f"{TRANSCEND}.yaml").connect()
			return (self.dest_conn, False)

		return (None, False)

	def run(self, printer: Callable[[str], None] = print) -> int:
		"start/resume running tasks sequentially. Return 2 if tasklist is paused because of lack of connection, else 0"
		printer(f"Executing Tasklist '{self.tasklist.name}' for Source System: '{self.srcsys.name}'")
		details_printer: Callable[[str], None] = printer if self.verbose else lambda _: None

		e = self.chkpt_step
		if e is None:
			if self.conn_src is Connect.Assist:
				bundle = self.assist_bundle()
				self.chkpt_step = 0
				printer(f"File '{bundle}' contains the needed assist-mode files. Restart after the *.tsv files have been received and copied to '{bundle.parent}'")
				return 0
			else:
				e = 0

		if e > 0:
			logger.warning("Source System: %s, Tasklist: %s restarting at step# %d", self.srcsys.name, self.tasklist.name, e + 1)

		try:
			numbered = enumerate(self.tasklist.tasks, start=1)
			positioned = dropwhile(lambda et: et[0] <= e, numbered)
			grouped = groupby(positioned, key=lambda x: x[1].connect)

			for connect, grp in grouped:
				try:
					conn, accept = self.get_conn(connect)
				except NotConnected as tdsys:
					logger.warning(
						"Source System: '%s', Tasklist: '%s' can't continue until connected to %s. Next task: #%d '%s'",
						self.srcsys.name,
						self.tasklist.name,
						str(tdsys),
						e + 1,
						self.tasklist.tasks[e].name)
					break

				for e, task in grp:
					if accept:
						if isinstance(task, M.ExportTask):
							csv = self.outdir / task.file
							tsv = csv.with_suffix('.tsv')
							if not tsv.exists():
								raise NoFileToConvert(f"Missing '{tsv}'")

							details_printer(f"  Task#{e:3d}: Converting {tsv} -> {csv.name}")
							with tsv.open('r', newline='') as i, csv.open('w', newline='') as o:
								r = reader(i, delimiter='\t')
								w = writer(o)
								w.writerows([col.strip() for col in row] for row in r)  # BTEQ pads short values with spaces
						else:
							details_printer(f"  Skipping Task#{e:3d}: {task}")
					else:
						details_printer(f"  Running Task#{e:3d}: {task}")
						task.run(conn, self.outdir)

				with self.chkpt_file.open('w') as f:
					json.dump(dict(tasklist=self.tasklist.name, srcsys=self.srcsys.name, last_tasknum=e), f)

			if e == len(self.tasklist.tasks):
				self.chkpt_file.unlink(missing_ok=True)

		finally:
			if self.src_conn is not None:
				self.src_conn.close()
			if self.dest_conn is not None:
				self.dest_conn.close()

		return 0

	def make_bteq(self) -> Tuple[str, List[Path]]:
		"return bteq script and list of input files from import tasks"
		data = []

		def csv_cols(p: Path) -> Tuple[List[str], List[int]]:
			"return list of column names and their max width for use in reading with the USING clause"
			with p.open(newline='') as fh:
				fr = reader(fh)
				columns = next(fr)  # the header row
				rows = list(fr)
				widths = [max(map(len, col)) for col in zip(*rows)]

				return (columns, widths)

		def csl(xs: Iterable[str]) -> str:
			"convert a str iterable to comma seperated lines"
			return ',\n  '.join(xs)

		def bteq_tasks() -> Iterable[str]:
			yield strip_pfx(
				""".SET MAXERROR 1
				|.SET SESSION TRANSACTION BTET;
				|.RUN file=login.bteq; -- update this file with the login information
				|.SET TITLEDASHES off;
				|.SET SEPARATOR '\t';
				|.SET NULL AS '';
				|.SET RETLIMIT * *;
				|.SET WIDTH 64000;
				|.SHOW CONTROLS;""")

			for t in filter(lambda t: t.connect is M.ConnectTarget.source, self.tasklist.tasks):
				yield f"\n-- {t.name}"

				if isinstance(t, M.ExportTask):
					yield strip_pfx(
						f""".export report file="{t.file.stem}.tsv" , close
						|{t.getsql()};
						|.export reset""")

				elif isinstance(t, M.ImportTask):
					columns, widths = csv_cols(t.inpdir / t.file)
					data.append(t.inpdir / t.file)

					yield strip_pfx(
						f""".import vartext ',' file="{Path('data') / t.file.name}", skip=1
						|.quiet on
						|.repeat * pack 10000
						|USING (
						|  {csl(f"{c} VARCHAR({w})" for c, w in zip(columns, widths))}
						|)
						|INSERT INTO {t.table} (
						|  {csl(columns)}
						|)
						|VALUES (
						|  {csl(f":{c}" for c in columns)}
						|);""")

				elif isinstance(t, M.SQLTask):
					yield t.getsql() + ';\n'

			yield "\n.LOGOFF\n.QUIT\n"

		return ('\n'.join(bteq_tasks()), data)

	def assist_bundle(self) -> Path:
		"create bundle artifacts needed for the assisted run and return path to it"
		bteq, incl = self.make_bteq()

		bundle = self.outdir / f"{self.tasklist.name}.zip"
		with ZipFile(bundle, mode='w') as z:
			z.writestr('RUNME.bteq', bteq)
			z.writestr('login.bteq', ".LOGMECH TD2; --- example options: NTLM, KRB5, LDAP, TD2\n.LOGON host/username,password;\n")
			for p in incl:
				z.write(p, Path('data') / p.name)

		return bundle


def make_runner(
	ssp: Path,
	tlp: Path,
	outdir: Path = Path('out'),
	conn_src: Connect = Connect.No,
	conn_dest: bool = False,
	verbose: bool = False) -> TaskListRunner:
	"make runnable tasklists from list of systems and tasklists"
	ss = M.load_tdsys(ssp)
	tl = M.load_tasklist(tlp, make_renderer(ssp.stem, tlp.stem))

	odir = outdir / ss.name
	if odir.exists():
		if not odir.is_dir():
			raise SystemExit(f"Output '{odir}' is not a directory")
	else:
		odir.mkdir(parents=True)

	return TaskListRunner(tl, ss, conn_src=conn_src, conn_dest=conn_dest, outdir=odir, verbose=verbose)
