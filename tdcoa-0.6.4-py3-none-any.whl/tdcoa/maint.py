"Check availability of, and download, new release of system tasks"
import logging
import os
from pathlib import Path

from . import __name__ as rootpkg, __version__
from .util import userdirs
from .model import VersionCheck

logger = logging.getLogger(__name__)
verchk = VersionCheck()


def init_app(h: logging.Handler, disable_logging=False) -> None:
	"initialize logging. if TDCOA_LOGFILE environment variable is set, log debug messages to that file"
	root_logger = logging.getLogger(rootpkg)

	h.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
	root_logger.addHandler(h)

	if logfile := os.environ.get('TDCOA_LOGFILE'):
		try:
			Path(logfile).parents[0].mkdir(parents=True, exist_ok=True)
			Path(logfile).touch(exist_ok=True)
			h2 = logging.FileHandler(logfile)
			h2.name = 'tdcoa_logfile_handler'
			h2.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
			h.setLevel(logging.WARNING)
			root_logger.setLevel(logging.DEBUG)
			root_logger.addHandler(h2)
			msg = None
		except Exception:
			msg = f"Failed to set logging target to $TDCOA_LOGFILE (='{logfile}')"
			logger.exception(msg)
	if disable_logging:
		handler = list(filter(lambda p: p.name == 'tdcoa_logfile_handler', root_logger.handlers))
		if handler:
			root_logger.removeHandler(handler[0])
	refresh()


def refresh(force_check: bool = False) -> str:
	"refresh system collection and application version information"
	app_ver = syscoll_ver = None

	if force_check or verchk.outdated:
		if verchk.cached_syscoll_ver != verchk.latest_syscoll_ver:
			syscoll_ver = verchk.latest_syscoll_ver
			verchk.syscoll_rel.download_to(userdirs.systasks)
		verchk.update()

	if __version__ < verchk.cached_app_ver:
		app_ver = verchk.cached_app_ver

	msgs = []
	if app_ver is not None:
		msgs.append(f"Application version '{app_ver}' is available for download")
	if syscoll_ver is not None:
		msgs.append(f"system collections updated to {syscoll_ver}")
	msg = "; ".join(msgs)
	if msg:
		logger.warning(msg)

	return msg


if __name__ == "__main__":
	refresh()
