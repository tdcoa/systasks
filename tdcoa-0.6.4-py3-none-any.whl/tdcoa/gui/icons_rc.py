# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 5.15.2
# WARNING! All changes made in this file will be lost!

from PySide2 import QtCore

qt_resource_data = b"\
\x00\x00\x02\x22\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a  <pa\
th style=\x22fill:c\
urrentColor;fill\
-opacity:1;strok\
e:none\x22 \x0a     d=\
\x22M 3 2 L 3 14 L \
8 14 L 8 13 L 4 \
13 L 4 3 L 9 3 L\
 9 6 L 12 6 L 12\
 9 L 13 9 L 13 6\
 L 13 5 L 10 2 L\
 9 2 L 3 2 z M 1\
0 9 L 10 11 L 8 \
11 L 8 12 L 10 1\
2 L 10 14 L 11 1\
4 L 11 12 L 13 1\
2 L 13 11 L 11 1\
1 L 11 9 L 10 9 \
z \x22\x0a     class=\x22\
ColorScheme-Text\
\x22\x0a     />\x0a</svg>\
\x0a\
\x00\x00\x04$\
<\
svg version=\x221.1\
\x22 id=\x22Layer_1\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 xmlns:xlink=\x22h\
ttp://www.w3.org\
/1999/xlink\x22 x=\x22\
0px\x22 y=\x220px\x22\x0a\x09 v\
iewBox=\x220 0 512 \
512\x22 style=\x22enab\
le-background:ne\
w 0 0 512 512;\x22 \
xml:space=\x22prese\
rve\x22>\x0a<g>\x0a\x09<path\
 d=\x22M36.8,292.8c\
0,39.5,10.1,76.4\
,29.8,110c19.7,3\
3.6,46.6,60.5,80\
.2,79.8c33.6,19.\
7,70.1,29.4,109.\
6,29.4\x0a\x09\x09c40.3,0\
,76.9-9.7,110.5-\
29c33.6-19.3,60-\
45.8,79.4-79.4c1\
9.3-33.6,29-70.6\
,29-110.5c0-10.1\
-3.4-18.5-10.1-2\
5.6\x0a\x09\x09c-6.7-7.1-\
14.7-10.5-24.8-1\
0.5c-9.7,0-18.1,\
3.4-25.2,10.5c-7\
.1,7.1-10.5,15.5\
-10.5,25.6c0,41.\
2-14.7,76.5-43.7\
,105.4\x0a\x09\x09c-29,29\
-64.3,43.7-105.4\
,43.7c-40.7,0-75\
.2-14.7-103.7-43\
.7c-28.6-29-42.8\
-64.3-42.8-105.4\
c0-35.7,10.9-68,\
33.2-97\x0a\x09\x09c22.3-\
29,47.9-44.5,77.\
3-46.2l-16,15.5c\
-6.7,7.5-10.1,15\
.5-10.1,24.3c0,9\
.2,3.4,17.7,10.1\
,25.2c15.1,14.7,\
32.3,14.7,50.8,0\
\x0a\x09\x09l77.3-76.4c6.\
7-5,10.1-13.9,10\
.1-26c0-10.9-3.4\
-18.9-10.1-23.9l\
-76.4-78.5C247.6\
,3.4,239.6,0,231\
.2,0c-10.5,0-19.\
3,3.4-26.5,10.5\x0a\
\x09\x09c-7.1,7.2-10.5\
,15.5-10.5,25.2c\
0,10.1,3.4,18.9,\
10.1,25.6l16,15.\
1c-52.5,9.2-96.2\
,34.4-131,75.6C5\
4.4,193.2,36.8,2\
39.8,36.8,292.8z\
\x0a\x09\x09\x22/>\x0a</g>\x0a</sv\
g>\x0a\
\x00\x00\x05\xe7\
<\
?xml version=\x221.\
0\x22 encoding=\x22iso\
-8859-1\x22?>\x0a<!-- \
Generator: Adobe\
 Illustrator 17.\
1.0, SVG Export \
Plug-In . SVG Ve\
rsion: 6.00 Buil\
d 0)  -->\x0a<!DOCT\
YPE svg PUBLIC \x22\
-//W3C//DTD SVG \
1.1//EN\x22 \x22http:/\
/www.w3.org/Grap\
hics/SVG/1.1/DTD\
/svg11.dtd\x22>\x0a<sv\
g version=\x221.1\x22 \
id=\x22Capa_1\x22 xmln\
s=\x22http://www.w3\
.org/2000/svg\x22 x\
mlns:xlink=\x22http\
://www.w3.org/19\
99/xlink\x22 x=\x220px\
\x22 y=\x220px\x22\x0a\x09 view\
Box=\x220 0 333.561\
 333.561\x22 style=\
\x22enable-backgrou\
nd:new 0 0 333.5\
61 333.561;\x22 xml\
:space=\x22preserve\
\x22>\x0a<path fill=\x22#\
ffbc00\x22 d=\x22M295.\
023,70.021c-10.6\
53-20.379-25.378\
-36.617-43.763-4\
8.265C228.47,7.3\
2,200.047,0,166.\
78,0s-61.69,7.32\
-84.48,21.757\x0a\x09c\
-18.386,11.647-3\
3.11,27.886-43.7\
63,48.265c-17.74\
5,33.944-18.257,\
67.888-18.257,71\
.646v182.064c0,1\
.4,0.001,2.673,0\
.036,3.596\x0a\x09c0.2\
14,5.784,4.052,6\
.233,5.223,6.233\
c2.327,0,3.61-1.\
173,7.316-4.88l0\
.213-0.214l34.96\
9-44.641l34.895,\
44.274l0.392,0.4\
41\x0a\x09c2.747,2.745\
,7.7,4.738,11.77\
9,4.738h3.416c4.\
08,0,9.033-1.993\
,11.779-4.739l0.\
21-0.21l35.064-4\
4.56l34.909,44.3\
11l0.393,0.441\x0a\x09\
c2.756,2.756,7.7\
1,4.756,11.779,4\
.756h3.416c4.08,\
0,9.034-1.993,11\
.78-4.739l0.21-0\
.21l35.063-44.55\
9l34.906,44.444l\
0.396,0.447\x0a\x09c1.\
47,1.47,5.23,4.8\
88,8.402,4.888c3\
.98,0,6.452-3.76\
3,6.452-9.82V141\
.668C313.28,137.\
909,312.768,103.\
966,295.023,70.0\
21z\x0a\x09 M109.354,1\
70.146c-17.999,0\
-32.59-14.591-32\
.59-32.59s14.591\
-32.59,32.59-32.\
59s32.591,14.591\
,32.591,32.59\x0a\x09S\
127.353,170.146,\
109.354,170.146z\
 M223.354,170.14\
6c-17.999,0-32.5\
9-14.591-32.59-3\
2.59s14.591-32.5\
9,32.59-32.59\x0a\x09s\
32.591,14.591,32\
.591,32.59S241.3\
53,170.146,223.3\
54,170.146z\x22/>\x0a<\
/svg>\x0a\
\x00\x00\x01\xf8\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 13.273438 3.5 \
L 5.6367188 11.0\
60547 L 2.726562\
5 8.1796875 L 2 \
8.9003906 L 4.90\
82031 11.779297 \
L 5.6367188 12.5\
 L 6.7265625 11.\
419922 L 14 4.22\
07031 L 13.27343\
8 3.5 z \x22\x0a     c\
lass=\x22ColorSchem\
e-Text\x22\x0a     />\x0a\
</svg>\x0a\
\x00\x00\x02\xdd\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 14 L 3\
 14 L 4 14 L 10 \
14 L 11 14 L 12 \
14 L 14 14 L 14 \
4.28125 L 11.718\
75 2 L 11.6875 2\
 L 11 2 L 4 2 L \
3 2 L 2 2 z M 3 \
3 L 4 3 L 5 3 L \
5 6 L 5 7 L 11 7\
 L 11 6 L 11 3 L\
 11.28125 3 L 13\
 4.71875 L 13 5 \
L 13 13 L 12 13 \
L 12 9 L 11 9 L \
5 9 L 3.96875 9 \
L 3.96875 13 L 3\
 13 L 3 3 z M 6 \
3 L 7.90625 3 L \
7.90625 6 L 6 6 \
L 6 3 z M 5 10 L\
 6 10 L 10 10 L \
11 10 L 11 13 L \
10 13 L 6 13 L 5\
 13 L 5 10 z \x22\x0a \
    class=\x22Color\
Scheme-Text\x22\x0a   \
  />\x0a</svg>\x0a\
\x00\x00\x02[\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
M 2 2 L 2 3 L 2 \
6 L 2 7 L 2 13 L\
 2 14 L 14 14 L \
14 13 L 14 6 L 1\
4 5 L 14 4 L 9.0\
078125 4 L 7.007\
8125 2 L 7 2.007\
8125 L 7 2 L 3 2\
 L 2 2 z M 3 3 L\
 6.5917969 3 L 7\
.59375 4 L 7 4 L\
 7 4.0078125 L 6\
.9921875 4 L 4.9\
921875 6 L 3 6 L\
 3 3 z M 3 7 L 1\
3 7 L 13 13 L 3 \
13 L 3 7 z \x22\x0a   \
  class=\x22ColorSc\
heme-Text\x22\x0a     \
/>\x0a</svg>\x0a\
\x00\x00\x01\xef\
<\
svg viewBox=\x220 0\
 16 16\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a    \
<style type=\x22tex\
t/css\x22 id=\x22curre\
nt-color-scheme\x22\
>\x0a        .Color\
Scheme-Text {\x0a  \
          color:\
#232629;\x0a       \
 }\x0a    </style>\x0a\
    <g class=\x22Co\
lorScheme-Text\x22 \
fill=\x22currentCol\
or\x22 fill-rule=\x22e\
venodd\x22>\x0a       \
 <path d=\x22m8 2a6\
 6 0 0 0 -6 6 6 \
6 0 0 0 6 6 6 6 \
0 0 0 6-6 6 6 0 \
0 0 -6-6zm0 1a5 \
5 0 0 1 5 5 5 5 \
0 0 1 -5 5 5 5 0\
 0 1 -5-5 5 5 0 \
0 1 5-5z\x22/>\x0a    \
    <path d=\x22m7 \
4h2v2h-2z\x22/>\x0a   \
     <path d=\x22m7\
 7h2v5h-2z\x22/>\x0a  \
  </g>\x0a</svg>\x0a\
\x00\x00\x02y\
<\
svg id=\x22svg6\x22 ve\
rsion=\x221.1\x22 view\
Box=\x220 0 16 16\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a    <style i\
d=\x22current-color\
-scheme\x22 type=\x22t\
ext/css\x22>.ColorS\
cheme-Text {\x0a   \
         color:#\
232629;\x0a        \
}</style>\x0a    <p\
ath id=\x22path4\x22 c\
lass=\x22ColorSchem\
e-Text\x22 d=\x22m7.5 \
2-3.5 3.5 3.5 3.\
5 0.71875-0.7187\
5-2.3125-2.28125\
h3.59375c1.93299\
8 0 3.5 1.566998\
4 3.5 3.5 0 1.93\
3002-1.567002 3.\
5-3.5 3.5h-1.5v1\
h1.5c2.485283 0 \
4.5-2.014748 4.5\
-4.5 0-2.4852521\
-2.014717-4.5-4.\
5-4.5h-3.59375l2\
.3125-2.28125z\x22 \
fill=\x22currentCol\
or\x22/>\x0a    <rect \
id=\x22rect837\x22 cla\
ss=\x22ColorScheme-\
Text\x22 x=\x222\x22 y=\x222\
\x22 width=\x221\x22 heig\
ht=\x227\x22 fill=\x22cur\
rentColor\x22 fill-\
rule=\x22evenodd\x22/>\
\x0a</svg>\x0a\
\x00\x00\x02X\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 2 L 3 1\
4 L 7 14 L 7 13 \
L 4 13 L 4 3 L 9\
 3 L 9 6 L 12 6 \
L 12 7 L 13 7 L \
13 5 L 10 2 L 3 \
2 Z M 12 8 L 8 1\
2 L 8 14 L 10 14\
 L 14 10 L 12 8 \
Z M 11.6894 9.68\
945 L 12.2813 10\
.2813 L 9.3125 1\
3.2813 L 8.71875\
 12.6875 L 11.68\
94 9.68945 Z\x22/>\x0a\
</svg>\x0a\
\x00\x00\x02S\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 7 12 L 11\
.0859 12 L 9.464\
84 13.6211 L 10.\
1719 14.3281 L 1\
3 11.5 L 10.1719\
 8.67187 L 9.464\
84 9.37891 L 11.\
0859 11 L 7 11 L\
 7 12 Z M 4 13 L\
 4 3 L 9 3 L 9 6\
 L 12 6 L 12 9 L\
 13 9 L 13 5 L 1\
0 2 L 3 2 L 3 14\
 L 8 14 L 8 13 L\
 4 13 Z\x22/>\x0a</svg\
>\x0a\
\x00\x00\x02\xfe\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a       d\
=\x22M 8 2 C 4.6862\
928 2 2 4.686299\
7 2 8 C 2 11.313\
7 4.6862928 14 8\
 14 C 11.313707 \
14 14 11.3137 14\
 8 C 14 4.686299\
7 11.313707 2 8 \
2 z M 8 3 C 10.7\
61424 3 13 5.238\
5763 13 8 C 13 9\
.199635 12.54803\
7 10.263384 11.8\
4375 11.125 L 4.\
875 4.15625 C 5.\
7366165 3.451962\
7 6.8003651 3 8 \
3 z M 4.15625 4.\
875 L 11.125 11.\
84375 C 10.26338\
4 12.548037 9.19\
9635 13 8 13 C 5\
.2385763 13 3 10\
.761424 3 8 C 3 \
6.8003651 3.4519\
627 5.7366165 4.\
15625 4.875 z \x22\x0a\
     class=\x22Colo\
rScheme-Text\x22\x0a  \
   />\x0a</svg>\x0a\
\x00\x00\x03\xf2\
<\
!DOCTYPE svg>\x0a<s\
vg viewBox=\x220 0 \
16 16\x22 version=\x22\
1.1\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a    <de\
fs>\x0a        <sty\
le type=\x22text/cs\
s\x22 id=\x22current-c\
olor-scheme\x22>\x0a  \
          .Color\
Scheme-Text {\x0a  \
              co\
lor:#232629;\x0a   \
         }\x0a     \
   </style>\x0a    \
</defs>\x0a    <pat\
h class=\x22ColorSc\
heme-Text\x22 style\
=\x22fill:currentCo\
lor; fill-opacit\
y:1; stroke:none\
\x22 d=\x22M 3 2 L 3 1\
4 L 10 14 L 10 1\
3 L 4 13 L 4 3 L\
 9 3 L 9 6 L 12 \
6 L 12 11 L 13 1\
1 L 13 5 L 10 2 \
L 3 2 Z\x22/>\x0a    <\
path class=\x22Colo\
rScheme-Text\x22 st\
yle=\x22fill:curren\
tColor; fill-opa\
city:1; stroke:n\
one\x22 d=\x22M 8.4882\
8 7 C 7.10757 7 \
5.98828 8.11929 \
5.98828 9.5 C 5.\
98828 10.8807 7.\
10757 12 8.48828\
 12 C 8.97811 11\
.9992 9.45691 11\
.8546 9.86523 11\
.584 L 12.2813 1\
4 L 12.9883 13.2\
93 L 10.5723 10.\
877 C 10.8428 10\
.4686 10.9875 9.\
98983 10.9883 9.\
5 C 10.9883 8.11\
929 9.86899 7 8.\
48828 7 Z M 8.48\
828 8 C 9.31671 \
8 9.98828 8.6715\
7 9.98828 9.5 C \
9.98828 10.3284 \
9.31671 11 8.488\
28 11 C 7.65985 \
11 6.98828 10.32\
84 6.98828 9.5 C\
 6.98828 8.67157\
 7.65985 8 8.488\
28 8 Z\x22/>\x0a</svg>\
\x0a\
\x00\x00\x01\xa1\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Nega\
tiveText {\x0a     \
   color:#da4453\
;\x0a      }\x0a      \
</style>\x0a  </def\
s>\x0a  <path\x0a     \
style=\x22fill:curr\
entColor;fill-op\
acity:1;stroke:n\
one\x22 \x0a     class\
=\x22ColorScheme-Ne\
gativeText\x22\x0a    \
 d=\x22m5 2v2h1v-1h\
4v1h1v-2h-5zm-3 \
3v1h2v8h8v-8h2v-\
1zm3 1h6v7h-6z\x22 \
\x0a     />\x0a</svg>\x0a\
\
\x00\x00\x01\x9e\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 16 16\x22>\x0a  <d\
efs id=\x22defs3051\
\x22>\x0a    <style ty\
pe=\x22text/css\x22 id\
=\x22current-color-\
scheme\x22>\x0a      .\
ColorScheme-Text\
 {\x0a        color\
:#232629;\x0a      \
}\x0a      </style>\
\x0a  </defs>\x0a <pat\
h style=\x22fill:cu\
rrentColor;fill-\
opacity:1;stroke\
:none\x22 \x0a     d=\x22\
m 2,2 0,12 11,0 \
0,-1 -10,0 0,-8 \
10,0 0,8 0,1 1,0\
 L 14,2 3,2 Z m \
4,4 0,6 4,-3 z\x22\x0a\
     class=\x22Colo\
rScheme-Text\x22\x0a  \
   />\x0a</svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x07\
\x04\xcaZ'\
\x00n\
\x00e\x00w\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0cj!\xc7\
\x00r\
\x00e\x00f\x00r\x00e\x00s\x00h\x00.\x00s\x00v\x00g\
\x00\x07\
\x08sZ\x07\
\x00a\
\x00p\x00p\x00.\x00s\x00v\x00g\
\x00\x06\
\x07^Z\xc7\
\x00o\
\x00k\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xc8U\xe7\
\x00s\
\x00a\x00v\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x06\xc1T\x07\
\x00o\
\x00p\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x08\
\x0c3W\x07\
\x00h\
\x00e\x00l\x00p\x00.\x00s\x00v\x00g\
\x00\x09\
\x09\xc7\xabG\
\x00r\
\x00e\x00s\x00e\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\x07W\xa7\
\x00e\
\x00d\x00i\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x06\x9a\xc4'\
\x00e\
\x00x\x00p\x00o\x00r\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x09\xb2jG\
\x00c\
\x00a\x00n\x00c\x00e\x00l\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0bG\xee\x07\
\x00i\
\x00n\x00s\x00p\x00e\x00c\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x07\
\x09\xc1Z'\
\x00r\
\x00u\x00n\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x0e\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01x\x93\x0aGa\
\x00\x00\x00\xd6\x00\x00\x00\x00\x00\x01\x00\x00\x1aA\
\x00\x00\x01x\x93\x0aG`\
\x00\x00\x00|\x00\x00\x00\x00\x00\x01\x00\x00\x11\x16\
\x00\x00\x01x\x93\x0aGb\
\x00\x00\x00T\x00\x00\x00\x00\x00\x01\x00\x00\x0c9\
\x00\x00\x01x\x93\x0aGb\
\x00\x00\x00@\x00\x00\x00\x00\x00\x01\x00\x00\x06N\
\x00\x00\x01x\x93\x0aG^\
\x00\x00\x00f\x00\x00\x00\x00\x00\x01\x00\x00\x0e5\
\x00\x00\x01x\x93\x0aGc\
\x00\x00\x00\xf0\x00\x00\x00\x00\x00\x01\x00\x00\x1c\x98\
\x00\x00\x01x\x93\x0aG^\
\x00\x00\x01@\x00\x00\x00\x00\x00\x01\x00\x00%5\
\x00\x00\x01x\x93\x0aGc\
\x00\x00\x00\xa8\x00\x00\x00\x00\x00\x01\x00\x00\x15h\
\x00\x00\x01x\x93\x0aGc\
\x00\x00\x00\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x17\xe5\
\x00\x00\x01x\x93\x0aG_\
\x00\x00\x01\x0a\x00\x00\x00\x00\x00\x01\x00\x00\x1f\x9a\
\x00\x00\x01x\x93\x0aGa\
\x00\x00\x00\x92\x00\x00\x00\x00\x00\x01\x00\x00\x13u\
\x00\x00\x01x\x93\x0aGa\
\x00\x00\x00$\x00\x00\x00\x00\x00\x01\x00\x00\x02&\
\x00\x00\x01x9\x0f\xc8V\
\x00\x00\x01&\x00\x00\x00\x00\x00\x01\x00\x00#\x90\
\x00\x00\x01x\x93\x0aG_\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
