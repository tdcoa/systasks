"Main Window of tdcoa GUI"
import platform

from PySide2 import QtWidgets as Qw
from PySide2.QtGui import QIcon, QCloseEvent

from ..maint import init_app
from .main_ui import Ui_MainWindow


class MainWindow(Qw.QMainWindow):
	"tdcoa application main window"
	log_handler = None

	def __init__(self) -> None:
		super(MainWindow, self).__init__()
		self.setLayout(Qw.QVBoxLayout())
		self.ui = Ui_MainWindow()
		self.ui.setupUi(self)
		self.log_handler = self.ui.logger.make_handler()
		MainWindow.log_handler = self.log_handler
		init_app(self.log_handler)
		self.ui.run_w.init2(self.ui.logger, self.ui.colls_w, self.ui.srcsys_w)
		self.ui.about_w.show_versions()

	def closeEvent(self, event: QCloseEvent) -> None:
		def keep_changes(which: str) -> bool:
			return Qw.QMessageBox.question(self, "Unsaved changes", f"Discard changes made to {which} and quit?") is Qw.QMessageBox.No

		if (self.ui.vars_w.changed() and keep_changes("Variables") or
			self.ui.srcsys_w.changed() and keep_changes("Source-Systems") or
			self.ui.colls_w.changed() and keep_changes("Collections")):
			event.ignore()
		else:
			super().closeEvent(event)


def main() -> None:
	app = Qw.QApplication()
	if platform.system() == "Darwin":
		Qw.QApplication.setStyle("Fusion")  # BUG: Macintosh style doesn't repaint the UI

	app.setWindowIcon(QIcon(":/icons/app.svg"))

	win = MainWindow()
	win.show()

	rc = app.exec_()
	if rc:
		raise SystemExit(rc)
