"About Widget that displays the application information"
import os
import sys
from datetime import datetime
from PySide2.QtWidgets import QMessageBox, QWidget

from .. import __version__
from ..maint import refresh, verchk, init_app
from ..model import COLLCONF
from ..util import userdirs
from .about_ui import Ui_About
from .util import edit_file, open_folder


class About(QWidget):
	def __init__(self, parent: QWidget) -> None:
		super().__init__(parent)
		self.ui = Ui_About()
		self.ui.setupUi(self)

		self.ui.srcsys_path.setText(str(userdirs.tdsys))
		self.ui.colls_path.setText(str(COLLCONF))
		self.ui.syscoll_path.setText(str(userdirs.systasks))
		self.ui.vars_path.setText(str(userdirs.vars / "default.yaml"))
		self.ui.syslogg_path.setText(str(userdirs.syslogg.absolute()))
		self.update_environment_logging_button_text()

	def show_versions(self) -> None:
		self.ui.app_ver.setText(__version__)
		self.ui.syscoll_ver.setText(verchk.cached_syscoll_ver or 'Unknown')

	def open_vars(self) -> None:
		edit_file(userdirs.vars / 'default.yaml')

	def open_syscoll(self) -> None:
		open_folder(userdirs.systasks)

	def open_colls(self) -> None:
		edit_file(COLLCONF)

	def open_srcsys(self) -> None:
		open_folder(userdirs.tdsys)

	def open_syslogg(self) -> None:
		open_folder(userdirs.syslogg)

	def runRefresh(self) -> None:
		# for local debugging enable the following line and comment next line
		# os.system('cd {} && {} -m tdcoa.gui &'.format(os.getcwd(), sys.executable))
		os.system('tdcoaw &')
		sys.exit()

	def check_for_updates(self) -> None:
		msg = refresh(force_check=True)
		QMessageBox.warning(self, "Check for updates", msg or "All components are up-to-date!")
		self.show_versions()

	def is_logging_enabled(self):
		if os.environ.get('TDCOA_LOGFILE'):
			return True
		return False

	def update_environment_logging_button_text(self):
		text = 'Enabled' if self.is_logging_enabled() else "Disabled"
		color = 'Blue' if self.is_logging_enabled() else "Red"
		self.ui.toggle_logging.setText(str(text))
		#self.ui.toggle_logging.setAutoFillBackground(color)

	def runToggleLogging(self) -> None:
		"""This will alternatively update TDCOA_LOGFILE environment variable
			from None to f'./log/{datetime.strftime(datetime.now(), "%Y%m%d-%H%M%S")}.txt'
			and vice versa
		"""
		disable_logging = False
		if not os.environ.get('TDCOA_LOGFILE'):
			os.environ['TDCOA_LOGFILE'] = f'./log/{datetime.strftime(datetime.now(), "%Y%m%d-%H%M%S")}.txt'
		elif 'TDCOA_LOGFILE' in os.environ:
			os.environ.pop("TDCOA_LOGFILE")
			disable_logging = True
		self.update_environment_logging_button_text()
		from .main import MainWindow
		init_app(MainWindow.log_handler, disable_logging=disable_logging)
