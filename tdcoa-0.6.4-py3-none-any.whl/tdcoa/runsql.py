"Run and optionally create a list of SQL files as a Tasklist"
import csv
from itertools import dropwhile, groupby
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple

from .model import ConnectTarget, ExportTask, SQLTask, load_tdsys
from .util import save_yaml


def parse_sqlfile(f: Path) -> Iterable[str]:
	"iterate over sqls by parsing them from a sqlfile"
	for sql in f.read_text().split(';'):
		sql = sql.rstrip().lstrip()
		if sql:
			yield sql


def csv_filename(stem: str) -> Path:
	"""
	return a new name that doesn't exist. names are built adding .csv suffix and
	optionally a number until a non-exiting file is found
	"""
	def csvname(n: int) -> Path:
		"first output is named without any suffix, subsequent outputs have suffixes starting with 2"
		return Path(f"{stem}.csv" if n == 1 else f"{stem}-{n}.csv")

	return next(dropwhile(Path.exists, map(csvname, range(1, 1000))))  # the first file that doesn't exist


def exec_sql(csr: Any, sql: str, base: Path) -> Optional[Path]:
	"run sql and return output filename if it returns a result-set"
	csr.execute(sql)
	if not csr.description:  # no result-set information => no export
		return None

	outf = csv_filename(base.stem)
	with outf.open("w") as f:
		w = csv.writer(f)
		w.writerow(d[0] for d in csr.description)
		w.writerows(csr)

	return outf


def make_tasks(inp_file: Path, execs: Sequence[Tuple[str, Optional[Path]]]) -> Iterable[Dict[str, Any]]:
	"if there is only one SQL execution per input file, use sqlfile, else use sql"
	for num, (sql, out_file) in enumerate(execs, start=1):

		task: Dict[str, Any] = dict(name=f"{inp_file}, SQL# {num}", connect=ConnectTarget.source)
		attrs: Dict[str, Any] = dict(sqlfile=inp_file) if len(execs) == 1 else dict(sql=sql)

		if out_file is None:
			task[SQLTask.tag] = attrs
		else:
			attrs['file'] = out_file
			task[ExportTask.tag] = attrs

		yield task


def runsql(ssp: Path, sqlfiles: Sequence[Path], save: Optional[Path]) -> None:
	"run sqls files in order and save it as a tasklist if path is provided"
	with load_tdsys(ssp).connect() as conn, conn.cursor() as csr:
		exec_hist = [(f, sql, exec_sql(csr, sql, f)) for f in sqlfiles for sql in parse_sqlfile(f)]

	if save is not None:
		save_yaml(
			dict(
				name=save.stem,
				description=f"Auto generated from {', '.join(map(lambda p: p.name, sqlfiles))}",
				tasks=[d for f, grp in groupby(exec_hist, key=lambda x: x[0]) for d in make_tasks(f, [(s, p) for _, s, p in grp])]
			),
			save
		)
