"tools sub-module of the cli module"
from argparse import ArgumentParser
from pathlib import Path

from ..runsql import runsql
from .util import add_srcsys


def add_subp(parser: ArgumentParser):
	subp = parser.add_subparsers(help='Choose one of the following:', dest='cmd', metavar='sub-command', required=True)

	p = subp.add_parser('runsql', help='Run SQLs, optionally convert to a tasklist')
	p.set_defaults(cmd=runsql)
	p.add_argument('sqlfiles', metavar='sqlfile', type=Path, nargs='+', help='one or more SQL files to run')
	add_srcsys(p)
	p.add_argument('--save', type=Path, help='Save the run as a tasklist')
