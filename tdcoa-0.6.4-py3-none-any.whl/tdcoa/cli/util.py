"common functions and types for the cli module"
from __future__ import annotations

from argparse import ArgumentParser, ArgumentTypeError
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Set

from .. import util as U
from ..model import Collection, load_collections, load_tasklist, load_tdsys
from ..tasker import Connect, TaskListRunner
from ..template import make_renderer


@dataclass
class TasklistRef:
	"A tasklist reference, collection and tasklist name"
	coll: Collection
	name: str

	@property
	def doc(self) -> str:
		return self.coll.docs[self.name]

	@property
	def tags(self) -> Set[str]:
		return self.coll.tags[self.name]

	@property
	def path(self) -> Path:
		return self.coll.tasklists[self.name]

	@staticmethod
	def parse(name: str) -> TasklistRef:
		if '.' in name:
			cn, tln = name.split('.', 1)
			cs = next((c for c in load_collections() if c.location.stem.lower() == cn), None)
			if cs is None:
				raise ArgumentTypeError(f"Invalid collection '{cn}'")
		else:
			cs, tln = load_collections(), name

		x = next(((c, tln) for c in cs if tln in c.tasklists), None)
		if x is None:
			raise ArgumentTypeError(f"Tasklist '{name}' not found")

		return TasklistRef(*x)


def make_tasker(
	srcsys: Iterable[Path],
	tasks: Iterable[Path],
	conn_src: Connect = Connect.No,
	conn_dest: bool = False,
	verbose: bool = False) -> Iterable[TaskListRunner]:
	"make runnable tasklists from list of systems and tasklists"
	for ssp in srcsys:
		ss = load_tdsys(ssp)

		odir = U.outdir / ss.name
		if odir.exists():
			if not odir.is_dir():
				raise SystemExit(f"Output '{odir}' is not a directory")
		else:
			odir.mkdir(parents=True)

		for tlp in tasks:
			tl = load_tasklist(tlp, make_renderer(ssp.stem, tlp.stem))
			yield TaskListRunner(tl, ss, conn_src=conn_src, conn_dest=conn_dest, outdir=odir, verbose=verbose)


def coll(name: str) -> Collection:
	"Find a collection name and return its path"
	c = next((c for c in load_collections() if c.location.stem.lower() == name.lower()), None)
	if c is None:
		raise ArgumentTypeError(f"'{name}' is not a valid collection name")
	return c


def srcsys_path(name: str) -> Path:
	"Find source-system and return its path"
	p = U.userdirs.tdsys / f"{name}.yaml"
	if not p.exists():
		raise ArgumentTypeError(f"Source system '{name}' has no definition in {U.userdirs.tdsys}")
	return p


def add_srcsys(p: ArgumentParser) -> None:
	p.add_argument('-s', '--srcsys', dest='ssp', metavar='srcsys', type=srcsys_path, required=True, help='Source system name')


def add_verbose(p: ArgumentParser) -> None:
	"add --verbose option"
	p.add_argument('-v', '--verbose', action='store_true', help='include verbose details')


def add_task_runner(p: ArgumentParser) -> None:
	x = p.add_mutually_exclusive_group()
	x.add_argument('-S', dest='conn_src', action='store_const', const=Connect.Yes, default=Connect.No, help='connected to source')
	x.add_argument('-A', dest='conn_src', action='store_const', const=Connect.Assist, help='assist mode, first generate BTEQ script, and then receive exported files')
	p.add_argument('-T', dest='conn_dest', action='store_true', help='connected to transcend')
	add_verbose(p)
