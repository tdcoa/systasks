
INSTALL INSTRUCTIONS for tdCOA
=============================================

1) Go to this SharePoint location and download tdcoa.zip:
    https://teradata.sharepoint.com/teams/SalesTech/COA/Collections/!Application/tdcoa.zip

2) Unzip to a directory to somewhere on your local drive

3) Double-Click the appropriate "command" file, depending on your OS
   - Windows   = "win--run.cmd"
   - Apple Mac = "mac--run.command"

4) Wait while the installer does stuff
   - the very first time you run, it will take a few minutes as
     python sets up a virtual environment at that location
     (you'll see a ./env/ folder in that directory)
   - it'll also download and install all dependencies

5) Once the application pops up, you can close the terminal window
   (windows will close automatically, mac may remain open)





Troubleshooting - Reasons you might encounter errors
-----------------------------------------------------
If something goes wrong, here are some high-level checks to perform:

a) Is Python 3.8.x or higher installed?   If not, jump to a2).  If you think
   python IS installed, try the test:
   test: on commandline, type> python --version
   expecting: Python 3.8.x  (or higher)

  a1) if the test returns an error, or a lower version of Python than 3.8.x
       try typing>  python3 --version
               or>  python3.8 --version
               or>  python3.9 --version
               or>  py --version
                    (rare, but some old windows machines have this abbreviation)

      if typing an alternate "python" name returns a good result, then you
      have python installed, but the PATH environment variable is incorrect.
      You can either:
       - modify your environment variable PATH to include the location to your
         python3.8 installation (good choice if you use python for other uses)
          or
       - edit the COA command file in #3 above, changing every line that currently
         calls "python" to instead call "python3" or whatever worked during your
         test (easiest /fastest choice)

  a2) if every trial of> "python --version" fails no matter what you try, you
      probably don't have python installed.  Go to this link and download the
      ** 64bit version ** of python for your operating system:
      https://www.python.org/downloads/
      - current version is 3.9, anything over 3.8 will work
      - this install is very easy /wizard driven, but if you have questions or
        need guidance, this is an excellent walk-thru:
        https://docs.python.org/3/using/windows.html
      - make sure you get the 64bit version(!)  COA will not work with 32bit
      - while doing the install, there will be a checkbox to "add to PATH"
        this is recommended, as it will prevent issues like a1)

  a3) if you know you have Anaconda setup, but you cannot get the expected
      results above... well, you're in for some wrestling.  The Anaconda distro
      will work, but requires some advanced changes to the PATH environment variable
      and to the COA startup script.  We're not going to cover this use-case here,
      but please let us know if this is a hard blocker for you, and we'll craft an 
      Anaconda-specific solution.

  a4) if you have applications that use an earlier version of python than 3.8, you 
      can have 2 versions of python installed on the same PC at the same time.  
      The only challenges here is setting your PATH to use the correct version of 
      python for each application.  In this case, you can NOT change your PATH
      variable, so existing applications continue to work as expected, then use a
      version-specific python call (i.e., > python3.9 ) for COA, and your normal 
      PATH location ( > python ) for everything else.     


b) If you have an older version of Windows, you MAY hit an error during the install
   stating:
      Microsoft Visual C++ 14.0 is required.  Get it with "Microsoft Visual C++ Biuld 
      Tools"  https://visualstudio.microsoft.com/downloads/

   This happens when you're running either an older version of Windows, or a Home edition
   of windows, or for some reason your Windows machine does not have a C compiler installed.
   
   Included in the zip file is a small application to begin the correct visual c++ install.