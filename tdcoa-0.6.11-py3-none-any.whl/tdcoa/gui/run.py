"Run Widget"
from collections import defaultdict
import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Set, Tuple, cast
from webbrowser import open as open_url

from PySide2 import QtWidgets as Qw
from PySide2.QtCore import QAbstractItemModel, QAbstractListModel, QModelIndex, Qt

from .. import util as U
from ..excp import OpErr
from ..model import (Collection, load_collections, load_tasklist, load_tdsys,
					tdsys_paths, vars_chain)
from ..tasker import Connect, TaskListRunner
from ..template import make_renderer
from .expl import TaskListDialog
from .logger import Logger
from .run_ui import Ui_Run
from .colls import Colls
from .srcsys import Srcsys
from .util import bold_font, open_folder

from ..util import load_yaml, save_yaml, userdirs

COLLCONF = userdirs.config / "filepaths.yaml"

def nth_tl(c: Collection, n: int) -> str:
	return next(tln for e, tln in enumerate(c.tasklists.keys()) if e == n)


def handle_error(f: Callable) -> Callable:
	"decorator that traps and shows any operational/unplanned errors"
	def wrapper(self, *args, **kwargs):
		try:
			f(self, *args, **kwargs)
		except OpErr as msg:
			self.logger.error("Error", str(msg))
		except Exception as e:
			self.logger.exception(e)

	return wrapper


def scan_restarts(outdir: Path) -> Dict[str, List[str]]:
	"scan for all restartable tasklists, and return Dict[tasklist-name, List[source-system-name]]"
	restarts = defaultdict(list)
	for r in outdir.glob('*/.restart-*.json'):
		ssn = r.parent.stem
		tln = r.stem[len(".restart-"):]
		restarts[tln].append(ssn)

	return restarts


class TaskListModel(QAbstractItemModel):
	"Hierarchical model to represent variables at different levels: Global > Source System > Tasklist"
	def __init__(self, outdir: Path):
		super().__init__()
		self.cs = [c for c in load_collections() if c.visible]
		self.selection: Set[Tuple[Collection, int]] = set()
		self.restarts = scan_restarts(outdir)

	def reset_collections(self) -> None:
		self.beginResetModel()
		self.cs = [c for c in load_collections() if c.visible]
		self.selection = set()
		self.endResetModel()

	def reset_restarts(self, outdir: Path, clear_selection: bool = False) -> None:
		new_restarts = scan_restarts(outdir)

		for e1, c in enumerate(self.cs):
			pix = self.index(e1, 0, QModelIndex())
			for e2, tln in enumerate(c.tasklists.keys()):
				if clear_selection and (c, e2) in self.selection:
					ix = self.index(e2, 0, pix)
					self.selection.remove((c, e2))
					self.dataChanged.emit(ix, ix)
				if new_restarts[tln] != self.restarts[tln]:
					ix = self.index(e2, 1, pix)
					self.restarts[tln] = new_restarts[tln]
					self.dataChanged.emit(ix, ix)

	def rowCount(self, parent: QModelIndex) -> int:
		if not parent.isValid():
			return len(self.cs)

		ptr = cast(Collection, parent.internalPointer())
		if ptr is None:
			return len(self.cs[parent.row()].tasklists)

		return 0

	def columnCount(self, parent: QModelIndex) -> int:
		return 2

	def data(self, index: QModelIndex, role: int) -> Any:
		ptr = cast(Collection, index.internalPointer())

		if role == Qt.DisplayRole:
			if index.column() == 0:
				if ptr is None:
					return self.cs[index.row()].location.stem
				return nth_tl(ptr, index.row())
			if index.column() == 1:
				if ptr is not None:
					tln = nth_tl(ptr, index.row())
					return ",".join(self.restarts[tln]) if tln in self.restarts else ""

		if role == Qt.CheckStateRole:
			if index.column() == 0 and ptr is not None:
				return Qt.Checked if (ptr, index.row()) in self.selection else Qt.Unchecked

		if role == Qt.FontRole:
			if ptr is None:
				return bold_font

	def setData(self, index: QModelIndex, value: Any, role: int) -> bool:
		if role == Qt.CheckStateRole:
			ptr = cast(Collection, index.internalPointer())
			if ptr is not None:
				ix = (ptr, index.row())
				if ix in self.selection:
					self.selection.remove(ix)
				else:
					self.selection.add(ix)
				self.dataChanged.emit(ix, ix)
				return True

		return False

	def index(self, row: int, col: int, parent: QModelIndex) -> QModelIndex:
		if not parent.isValid():  # root item
			return self.createIndex(row, col, None)

		if parent.internalPointer() is None:
			return self.createIndex(row, col, self.cs[parent.row()])  # collection

		return QModelIndex()

	def parent(self, index: QModelIndex) -> QModelIndex:
		ptr = cast(Collection, index.internalPointer())
		if ptr is None:
			return QModelIndex()
		return self.createIndex(next(e for e, v in enumerate(self.cs) if v is ptr), 0, None)

	def headerData(self, section: int, orientation: Qt.Orientation, role: int) -> Any:
		if orientation == Qt.Horizontal and role == Qt.DisplayRole:
			return ["Collection > Processes", "Restartable?"][section]

	def flags(self, index: QModelIndex) -> Qt.ItemFlag:
		f = Qt.ItemIsEnabled | Qt.ItemIsSelectable
		if index.column() == 0 and index.internalPointer() is not None:
			f |= Qt.ItemIsUserCheckable
		return f


class SrcsysListModel(QAbstractListModel):
	"source system list model"
	def __init__(self):
		super().__init__()
		self.items = tdsys_paths()
		self.selection: Set[int] = set()

	def reset_model(self) -> None:
		self.beginResetModel()
		self.items = tdsys_paths()
		self.selection = set()
		self.endResetModel()

	def rowCount(self, parent: QModelIndex) -> int:
		return len(self.items)

	def data(self, index: QModelIndex, role: int) -> Any:
		if role == Qt.DisplayRole:
			return self.items[index.row()].stem

		if role == Qt.CheckStateRole:
			return Qt.Checked if index.row() in self.selection else Qt.Unchecked

	def setData(self, index: QModelIndex, value: Any, role: int) -> bool:
		if role == Qt.CheckStateRole:
			ix = index.row()
			if ix in self.selection:
				self.selection.remove(ix)
			else:
				self.selection.add(ix)
			self.dataChanged.emit(ix, ix)
			return True

		return False

	def headerData(self, section: int, orientation: Qt.Orientation, role: int) -> Any:
		if orientation == Qt.Horizontal and role == Qt.DisplayRole:
			return "Source System"

	def flags(self, index: QModelIndex) -> Qt.ItemFlag:
		return Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsUserCheckable


class Run(Qw.QWidget):
	def __init__(self, parent: Qw.QWidget) -> None:
		super().__init__(parent)
		self.ui = Ui_Run()
		self.ui.setupUi(self)
		self.timestamp_button_status = False
		self.curr_time_dir = None

	def init2(self, logger: Logger, coll_w: Colls, srcsys_w: Srcsys) -> None:
		"initialize phase 2: set logger and read and set models"
		self.logger = logger
		self.ssps = tdsys_paths()
		if COLLCONF.exists():
			self.outdir = Path(load_yaml(COLLCONF)['output_file_path'])
		else:
			self.outdir = Path('out')

		self.tlmodel = TaskListModel(self.outdir)
		self.ui.tasklist.setModel(self.tlmodel)
		self.ui.tasklist.collapseAll()
		self.ui.tasklist.header().setSectionResizeMode(0, Qw.QHeaderView.Stretch)
		self.ui.tasklist.header().setSectionResizeMode(1, Qw.QHeaderView.ResizeToContents)
		self.ui.tasklist.selectionModel().selectionChanged.connect(self.tlActions)
		self.ui.tasklist.model().dataChanged.connect(self.itemsChanged)

		def rescan_collections():
			cast(TaskListModel, self.ui.tasklist.model()).reset_collections()
			self.ui.tasklist.collapseAll()

		coll_w.changed_slot = rescan_collections

		self.ssmodel = SrcsysListModel()
		self.ui.srcsys.setModel(self.ssmodel)
		self.ui.srcsys.selectionModel().selectionChanged.connect(self.tlActions)
		self.ui.srcsys.model().dataChanged.connect(self.itemsChanged)
		srcsys_w.changed_slot = self.ssmodel.reset_model

		self.setOutdir(self.outdir)

	def itemsChanged(self) -> None:
		"evaluate buttons' enabled state"
		srcsys_selected = len(self.ssmodel.selection) > 0
		tasklist_selected = len(self.tlmodel.selection) > 0
		self.ui.pb_run.setEnabled(srcsys_selected and tasklist_selected)

	def tlActions(self):
		"enable/disable explain and help buttons"
		coll = cast(Collection, ixl[0].internalPointer()) if len(ixl := self.ui.tasklist.selectedIndexes()) > 0 else None
		tl_name = nth_tl(coll, ixl[0].row()) if coll is not None else None

		self.ui.pb_help.setEnabled(tl_name is not None and coll.docs[tl_name] is not None)
		self.ui.pb_explain.setEnabled(tl_name is not None)

	def setOutdir(self, new_dir: Path) -> None:
		self.outdir = new_dir
		try:
			d = str(self.outdir.relative_to(Path.cwd()))
		except ValueError:
			d = str(self.outdir)
		self.ui.output_dir.setText(d)
		self.tlmodel.reset_restarts(self.outdir)
		save_yaml({"output_file_path": self.outdir}, COLLCONF)

	def showHelp(self) -> None:
		coll = cast(Collection, (ixl := self.ui.tasklist.selectedIndexes())[0].internalPointer())
		tln = nth_tl(coll, ixl[0].row())
		open_url(coll.docs[tln] or '')

	@handle_error
	def showDetails(self) -> None:
		overrides = {}
		if self.ui.start_date.textval is not None:
			overrides['startdate'] = self.ui.start_date.textval
		if self.ui.end_date.textval is not None:
			overrides['enddate'] = self.ui.end_date.textval
		coll = cast(Collection, (ixl := self.ui.tasklist.selectedIndexes())[0].internalPointer())
		tlp = coll.tasklists[nth_tl(coll, ixl[0].row())]
		if len(self.ui.srcsys.selectedIndexes()) > 0:
			ssp = self.ssmodel.items[self.ui.srcsys.selectedIndexes()[0].row()]
		else:
			ssp = U.userdirs.tdsys / f'{U.TRANSCEND}.yaml'

		TaskListDialog(self, ssp, tlp, overrides).exec_()

	def sel_dir(self) -> None:
		"show directory selection dialog"
		new_dir = Qw.QFileDialog.getExistingDirectory(self, "Output folder", self.ui.output_dir.text(), Qw.QFileDialog.ShowDirsOnly)
		if new_dir:
			self.setOutdir(Path(new_dir))

	def open_outdir(self) -> None:
		"open output directory"
		open_folder(Path(self.outdir if self.outdir.exists() else Path.cwd()))

	def iter_ssp(self) -> Iterable[Path]:
		"iterate over selected source-system names"
		for ssw in map(self.ui.srcsys.item, range(self.ui.srcsys.count())):
			if ssw.checkState() == Qt.CheckState.Checked:
				yield ssw.data(Qt.UserRole)

	def output_timestamp_button(self):
		self.timestamp_button_status = self.ui.pb_timestamp.isChecked()

	@handle_error
	def tlRun(self) -> None:
		"execute run, produce bteq or consume files"
		overrides = {}
		if self.ui.start_date.textval is not None:
			overrides['startdate'] = self.ui.start_date.textval
		if self.ui.end_date.textval is not None:
			overrides['enddate'] = self.ui.end_date.textval

		def source_connection(ssn: str) -> Connect:
			if self.ui.source_setting.isChecked():
				return Connect.Yes if vars_chain(ssn)['connectable'] else Connect.Assist
			if self.ui.source_assist.isChecked():
				return Connect.Assist
			if self.ui.source_none.isChecked():
				return Connect.No
			return Connect.Yes

		def run_tasklist(ssp: Path, tlp: Path) -> None:
			"play a single tasklist"
			ss = load_tdsys(ssp)
			tl = load_tasklist(tlp, make_renderer(ssp.stem, tlp.stem, **overrides))
			if self.timestamp_button_status:
				curr_time = datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S')
				self.curr_time_dir = curr_time
				odir = self.outdir / curr_time / ss.name
			else:
				odir = self.outdir / ss.name
			if odir.exists():
				if not odir.is_dir():
					raise FileExistsError(f"Output '{odir}' exists and it's not a directory")
			else:
				odir.mkdir(parents=True)

			conn_src = source_connection(ssp.stem)
			conn_dest = self.ui.dest_connect.isChecked()
			TaskListRunner(tl, ss, odir, conn_src, conn_dest, True).run(printer=self.logger.log)

		Qw.QApplication.setOverrideCursor(Qt.WaitCursor)
		try:
			self.logger.show_logs(True)
			U.clear_lru_cache()
			for i in sorted(self.ssmodel.selection):
				for c, j in self.tlmodel.selection:
					run_tasklist(self.ssmodel.items[i], c.tasklists[nth_tl(c, j)])
			self.logger.info("Tasklist(s) processed successfully")
		finally:
			if self.timestamp_button_status:
				out_dir = self.outdir / self.curr_time_dir
			else:
				out_dir = self.outdir
			self.tlmodel.reset_restarts(out_dir, clear_selection=True)
			Qw.QApplication.restoreOverrideCursor()

	def runReset(self):
		if self.timestamp_button_status:
			out_dir = self.outdir / self.curr_time_dir
		else:
			out_dir = self.outdir
		for r in out_dir.glob('*/.restart-*.json'):
			r.unlink(missing_ok=True)
		self.tlmodel.reset_restarts(out_dir, clear_selection=True)
		Qw.QApplication.restoreOverrideCursor()
