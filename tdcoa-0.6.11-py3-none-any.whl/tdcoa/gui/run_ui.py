# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'run.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from .util import NLineEdit

from  . import icons_rc

class Ui_Run(object):
    def setupUi(self, Run):
        if not Run.objectName():
            Run.setObjectName(u"Run")
        Run.resize(830, 726)
        self.horizontalLayout_3 = QHBoxLayout(Run)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.splitter = QSplitter(Run)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setOrientation(Qt.Horizontal)
        self.widget = QWidget(self.splitter)
        self.widget.setObjectName(u"widget")
        self.verticalLayout_4 = QVBoxLayout(self.widget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.label_7 = QLabel(self.widget)
        self.label_7.setObjectName(u"label_7")

        self.horizontalLayout_14.addWidget(self.label_7)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_14.addItem(self.horizontalSpacer_5)

        self.pb_explain = QPushButton(self.widget)
        self.pb_explain.setObjectName(u"pb_explain")
        self.pb_explain.setEnabled(False)
        icon = QIcon()
        icon.addFile(u":/icons/inspect.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_explain.setIcon(icon)

        self.horizontalLayout_14.addWidget(self.pb_explain)

        self.pb_help = QPushButton(self.widget)
        self.pb_help.setObjectName(u"pb_help")
        self.pb_help.setEnabled(False)
        icon1 = QIcon()
        icon1.addFile(u":/icons/help.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_help.setIcon(icon1)

        self.horizontalLayout_14.addWidget(self.pb_help)

        self.pb_reset = QPushButton(self.widget)
        self.pb_reset.setObjectName(u"pb_reset")
        icon2 = QIcon()
        icon2.addFile(u":/icons/reset.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_reset.setIcon(icon2)

        self.horizontalLayout_14.addWidget(self.pb_reset)


        self.verticalLayout_4.addLayout(self.horizontalLayout_14)

        self.tasklist = QTreeView(self.widget)
        self.tasklist.setObjectName(u"tasklist")
        self.tasklist.setAlternatingRowColors(True)
        self.tasklist.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tasklist.header().setStretchLastSection(False)

        self.verticalLayout_4.addWidget(self.tasklist)

        self.splitter.addWidget(self.widget)
        self.widget1 = QWidget(self.splitter)
        self.widget1.setObjectName(u"widget1")
        self.horizontalLayout_12 = QHBoxLayout(self.widget1)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_8 = QLabel(self.widget1)
        self.label_8.setObjectName(u"label_8")

        self.verticalLayout_5.addWidget(self.label_8)

        self.srcsys = QListView(self.widget1)
        self.srcsys.setObjectName(u"srcsys")
        self.srcsys.setAlternatingRowColors(True)
        self.srcsys.setLayoutMode(QListView.Batched)

        self.verticalLayout_5.addWidget(self.srcsys)

        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.groupBox_4 = QGroupBox(self.widget1)
        self.groupBox_4.setObjectName(u"groupBox_4")
        self.formLayout_4 = QFormLayout(self.groupBox_4)
        self.formLayout_4.setObjectName(u"formLayout_4")
        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.output_dir = QLineEdit(self.groupBox_4)
        self.output_dir.setObjectName(u"output_dir")
        self.output_dir.setReadOnly(True)

        self.horizontalLayout_17.addWidget(self.output_dir)

        self.open_output = QPushButton(self.groupBox_4)
        self.open_output.setObjectName(u"open_output")
        icon3 = QIcon()
        icon3.addFile(u":/icons/open.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.open_output.setIcon(icon3)

        self.horizontalLayout_17.addWidget(self.open_output)


        self.formLayout_4.setLayout(12, QFormLayout.FieldRole, self.horizontalLayout_17)

        self.label = QLabel(self.groupBox_4)
        self.label.setObjectName(u"label")

        self.formLayout_4.setWidget(11, QFormLayout.LabelRole, self.label)

        self.label_12 = QLabel(self.groupBox_4)
        self.label_12.setObjectName(u"label_12")

        self.formLayout_4.setWidget(9, QFormLayout.LabelRole, self.label_12)

        self.start_date = NLineEdit(self.groupBox_4)
        self.start_date.setObjectName(u"start_date")

        self.formLayout_4.setWidget(9, QFormLayout.FieldRole, self.start_date)

        self.end_date = NLineEdit(self.groupBox_4)
        self.end_date.setObjectName(u"end_date")

        self.formLayout_4.setWidget(11, QFormLayout.FieldRole, self.end_date)

        self.pick_output = QPushButton(self.groupBox_4)
        self.pick_output.setObjectName(u"pick_output")
        self.pick_output.setIcon(icon3)

        self.formLayout_4.setWidget(12, QFormLayout.LabelRole, self.pick_output)

        self.pb_timestamp = QCheckBox(self.groupBox_4)
        self.pb_timestamp.setObjectName(u"pb_timestamp")

        self.formLayout_4.setWidget(13, QFormLayout.FieldRole, self.pb_timestamp)


        self.verticalLayout_3.addWidget(self.groupBox_4)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.groupBox_3 = QGroupBox(self.widget1)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.verticalLayout_2 = QVBoxLayout(self.groupBox_3)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.source_none = QRadioButton(self.groupBox_3)
        self.source_none.setObjectName(u"source_none")

        self.verticalLayout_2.addWidget(self.source_none)

        self.source_connect = QRadioButton(self.groupBox_3)
        self.source_connect.setObjectName(u"source_connect")

        self.verticalLayout_2.addWidget(self.source_connect)

        self.source_setting = QRadioButton(self.groupBox_3)
        self.source_setting.setObjectName(u"source_setting")
        self.source_setting.setChecked(True)

        self.verticalLayout_2.addWidget(self.source_setting)

        self.source_assist = QRadioButton(self.groupBox_3)
        self.source_assist.setObjectName(u"source_assist")

        self.verticalLayout_2.addWidget(self.source_assist)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.verticalLayout_2.addItem(self.horizontalSpacer_2)


        self.horizontalLayout.addWidget(self.groupBox_3)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.groupBox = QGroupBox(self.widget1)
        self.groupBox.setObjectName(u"groupBox")
        self.verticalLayout = QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.dest_none = QRadioButton(self.groupBox)
        self.dest_none.setObjectName(u"dest_none")

        self.verticalLayout.addWidget(self.dest_none)

        self.dest_connect = QRadioButton(self.groupBox)
        self.dest_connect.setObjectName(u"dest_connect")
        self.dest_connect.setChecked(True)

        self.verticalLayout.addWidget(self.dest_connect)


        self.verticalLayout_6.addWidget(self.groupBox)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_6.addItem(self.verticalSpacer)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)

        self.pb_run = QPushButton(self.widget1)
        self.pb_run.setObjectName(u"pb_run")
        self.pb_run.setEnabled(False)
        icon4 = QIcon()
        icon4.addFile(u":/icons/run.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_run.setIcon(icon4)

        self.horizontalLayout_2.addWidget(self.pb_run)


        self.verticalLayout_6.addLayout(self.horizontalLayout_2)


        self.horizontalLayout.addLayout(self.verticalLayout_6)


        self.verticalLayout_3.addLayout(self.horizontalLayout)


        self.verticalLayout_5.addLayout(self.verticalLayout_3)


        self.horizontalLayout_12.addLayout(self.verticalLayout_5)

        self.splitter.addWidget(self.widget1)

        self.horizontalLayout_3.addWidget(self.splitter)


        self.retranslateUi(Run)
        self.pb_reset.clicked.connect(Run.runReset)
        self.pb_help.clicked.connect(Run.showHelp)
        self.pb_explain.clicked.connect(Run.showDetails)
        self.pb_run.clicked.connect(Run.tlRun)
        self.open_output.clicked.connect(Run.open_outdir)
        self.pick_output.clicked.connect(Run.sel_dir)
        self.pb_timestamp.toggled.connect(Run.output_timestamp_button)

        QMetaObject.connectSlotsByName(Run)
    # setupUi

    def retranslateUi(self, Run):
        Run.setWindowTitle(QCoreApplication.translate("Run", u"Form", None))
        self.label_7.setText(QCoreApplication.translate("Run", u"Tasklists", None))
#if QT_CONFIG(tooltip)
        self.pb_explain.setToolTip(QCoreApplication.translate("Run", u"Show individual steps", None))
#endif // QT_CONFIG(tooltip)
        self.pb_explain.setText(QCoreApplication.translate("Run", u"Explain", None))
#if QT_CONFIG(tooltip)
        self.pb_help.setToolTip(QCoreApplication.translate("Run", u"Browse tasklist documentation", None))
#endif // QT_CONFIG(tooltip)
        self.pb_help.setText(QCoreApplication.translate("Run", u"Help", None))
#if QT_CONFIG(tooltip)
        self.pb_reset.setToolTip(QCoreApplication.translate("Run", u"Reset all restartable", None))
#endif // QT_CONFIG(tooltip)
        self.pb_reset.setText(QCoreApplication.translate("Run", u"Reset", None))
        self.label_8.setText(QCoreApplication.translate("Run", u"Source Systems", None))
        self.groupBox_4.setTitle(QCoreApplication.translate("Run", u"Options", None))
#if QT_CONFIG(tooltip)
        self.open_output.setToolTip(QCoreApplication.translate("Run", u"Open", None))
#endif // QT_CONFIG(tooltip)
        self.label.setText(QCoreApplication.translate("Run", u"End Date", None))
        self.label_12.setText(QCoreApplication.translate("Run", u"Start Date", None))
#if QT_CONFIG(tooltip)
        self.pick_output.setToolTip(QCoreApplication.translate("Run", u"Select output folder", None))
#endif // QT_CONFIG(tooltip)
        self.pick_output.setText(QCoreApplication.translate("Run", u"Output", None))
        self.pb_timestamp.setText(QCoreApplication.translate("Run", u"Add Timestamp SubFolder", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("Run", u"Connect Source?", None))
#if QT_CONFIG(tooltip)
        self.source_none.setToolTip(QCoreApplication.translate("Run", u"Do not connect to Source System", None))
#endif // QT_CONFIG(tooltip)
        self.source_none.setText(QCoreApplication.translate("Run", u"Skip", None))
#if QT_CONFIG(tooltip)
        self.source_connect.setToolTip(QCoreApplication.translate("Run", u"Connect to Source System", None))
#endif // QT_CONFIG(tooltip)
        self.source_connect.setText(QCoreApplication.translate("Run", u"Connect", None))
#if QT_CONFIG(tooltip)
        self.source_setting.setToolTip(QCoreApplication.translate("Run", u"Use value from Source specific variable", None))
#endif // QT_CONFIG(tooltip)
        self.source_setting.setText(QCoreApplication.translate("Run", u"Use Setting", None))
#if QT_CONFIG(tooltip)
        self.source_assist.setToolTip(QCoreApplication.translate("Run", u"Generate/Use scripts", None))
#endif // QT_CONFIG(tooltip)
        self.source_assist.setText(QCoreApplication.translate("Run", u"Assist Mode", None))
        self.groupBox.setTitle(QCoreApplication.translate("Run", u"Connect Transcend?", None))
#if QT_CONFIG(tooltip)
        self.dest_none.setToolTip(QCoreApplication.translate("Run", u"Do not connect to Transcend", None))
#endif // QT_CONFIG(tooltip)
        self.dest_none.setText(QCoreApplication.translate("Run", u"Skip", None))
#if QT_CONFIG(tooltip)
        self.dest_connect.setToolTip(QCoreApplication.translate("Run", u"Connect to Transcend", None))
#endif // QT_CONFIG(tooltip)
        self.dest_connect.setText(QCoreApplication.translate("Run", u"Connect", None))
#if QT_CONFIG(tooltip)
        self.pb_run.setToolTip(QCoreApplication.translate("Run", u"Run checked tasklists for checked source systems", None))
#endif // QT_CONFIG(tooltip)
        self.pb_run.setText(QCoreApplication.translate("Run", u"Run", None))
    # retranslateUi

