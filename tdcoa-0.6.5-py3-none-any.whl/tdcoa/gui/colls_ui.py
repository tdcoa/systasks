# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'colls.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from  . import icons_rc

class Ui_Colls(object):
    def setupUi(self, Colls):
        if not Colls.objectName():
            Colls.setObjectName(u"Colls")
        Colls.resize(916, 692)
        self.verticalLayout = QVBoxLayout(Colls)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.splitter = QSplitter(Colls)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setOrientation(Qt.Horizontal)
        self.list_area = QWidget(self.splitter)
        self.list_area.setObjectName(u"list_area")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(5)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.list_area.sizePolicy().hasHeightForWidth())
        self.list_area.setSizePolicy(sizePolicy)
        self.verticalLayout_2 = QVBoxLayout(self.list_area)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.pb_new = QPushButton(self.list_area)
        self.pb_new.setObjectName(u"pb_new")
        icon = QIcon()
        icon.addFile(u":/icons/new.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_new.setIcon(icon)

        self.horizontalLayout_4.addWidget(self.pb_new)

        self.pb_del = QPushButton(self.list_area)
        self.pb_del.setObjectName(u"pb_del")
        icon1 = QIcon()
        icon1.addFile(u":/icons/delete.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_del.setIcon(icon1)

        self.horizontalLayout_4.addWidget(self.pb_del)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_3)

        self.pb_up = QPushButton(self.list_area)
        self.pb_up.setObjectName(u"pb_up")

        self.horizontalLayout_4.addWidget(self.pb_up)

        self.pb_down = QPushButton(self.list_area)
        self.pb_down.setObjectName(u"pb_down")

        self.horizontalLayout_4.addWidget(self.pb_down)


        self.verticalLayout_2.addLayout(self.horizontalLayout_4)

        self.colls_list = QTableView(self.list_area)
        self.colls_list.setObjectName(u"colls_list")
        self.colls_list.setAlternatingRowColors(True)
        self.colls_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.colls_list.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.colls_list.horizontalHeader().setStretchLastSection(True)
        self.colls_list.verticalHeader().setVisible(False)

        self.verticalLayout_2.addWidget(self.colls_list)

        self.splitter.addWidget(self.list_area)
        self.edit_area = QWidget(self.splitter)
        self.edit_area.setObjectName(u"edit_area")
        self.edit_area.setEnabled(True)
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(3)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.edit_area.sizePolicy().hasHeightForWidth())
        self.edit_area.setSizePolicy(sizePolicy1)
        self.verticalLayout_4 = QVBoxLayout(self.edit_area)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.gb_conn = QGroupBox(self.edit_area)
        self.gb_conn.setObjectName(u"gb_conn")
        self.formLayout = QFormLayout(self.gb_conn)
        self.formLayout.setObjectName(u"formLayout")
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.local_path = QLineEdit(self.gb_conn)
        self.local_path.setObjectName(u"local_path")
        self.local_path.setReadOnly(True)

        self.horizontalLayout_3.addWidget(self.local_path)

        self.pb_open_loc = QPushButton(self.gb_conn)
        self.pb_open_loc.setObjectName(u"pb_open_loc")
        icon2 = QIcon()
        icon2.addFile(u":/icons/open.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_open_loc.setIcon(icon2)

        self.horizontalLayout_3.addWidget(self.pb_open_loc)


        self.formLayout.setLayout(2, QFormLayout.FieldRole, self.horizontalLayout_3)

        self.label = QLabel(self.gb_conn)
        self.label.setObjectName(u"label")

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.label)

        self.notes = QPlainTextEdit(self.gb_conn)
        self.notes.setObjectName(u"notes")

        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.notes)

        self.label_3 = QLabel(self.gb_conn)
        self.label_3.setObjectName(u"label_3")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_3)

        self.pb_visible = QCheckBox(self.gb_conn)
        self.pb_visible.setObjectName(u"pb_visible")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.pb_visible)

        self.pb_pick_loc = QPushButton(self.gb_conn)
        self.pb_pick_loc.setObjectName(u"pb_pick_loc")
        self.pb_pick_loc.setIcon(icon2)

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.pb_pick_loc)


        self.verticalLayout_4.addWidget(self.gb_conn)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_11.addItem(self.horizontalSpacer_2)

        self.pb_cancel = QPushButton(self.edit_area)
        self.pb_cancel.setObjectName(u"pb_cancel")
        self.pb_cancel.setEnabled(False)
        icon3 = QIcon()
        icon3.addFile(u":/icons/cancel.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_cancel.setIcon(icon3)

        self.horizontalLayout_11.addWidget(self.pb_cancel)

        self.pb_save = QPushButton(self.edit_area)
        self.pb_save.setObjectName(u"pb_save")
        self.pb_save.setEnabled(False)
        icon4 = QIcon()
        icon4.addFile(u":/icons/save.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_save.setIcon(icon4)

        self.horizontalLayout_11.addWidget(self.pb_save)


        self.verticalLayout_4.addLayout(self.horizontalLayout_11)

        self.splitter.addWidget(self.edit_area)

        self.verticalLayout.addWidget(self.splitter)

        QWidget.setTabOrder(self.colls_list, self.pb_cancel)
        QWidget.setTabOrder(self.pb_cancel, self.pb_save)

        self.retranslateUi(Colls)
        self.pb_down.clicked.connect(Colls.move_down)
        self.pb_up.clicked.connect(Colls.move_up)
        self.pb_open_loc.clicked.connect(Colls.open_location)
        self.pb_save.clicked.connect(Colls.save_changes)
        self.pb_new.clicked.connect(Colls.add_new)
        self.notes.textChanged.connect(Colls.data_changed)
        self.pb_visible.toggled.connect(Colls.data_changed)
        self.pb_del.clicked.connect(Colls.delete_curr)
        self.pb_cancel.clicked.connect(Colls.discard_changes)
        self.pb_pick_loc.clicked.connect(Colls.set_location)

        QMetaObject.connectSlotsByName(Colls)
    # setupUi

    def retranslateUi(self, Colls):
        Colls.setWindowTitle(QCoreApplication.translate("Colls", u"Form", None))
#if QT_CONFIG(tooltip)
        self.pb_new.setToolTip(QCoreApplication.translate("Colls", u"Add a new collection", None))
#endif // QT_CONFIG(tooltip)
        self.pb_new.setText(QCoreApplication.translate("Colls", u"Add", None))
#if QT_CONFIG(tooltip)
        self.pb_del.setToolTip(QCoreApplication.translate("Colls", u"Remove selected collection", None))
#endif // QT_CONFIG(tooltip)
        self.pb_del.setText(QCoreApplication.translate("Colls", u"Remove", None))
#if QT_CONFIG(tooltip)
        self.pb_up.setToolTip(QCoreApplication.translate("Colls", u"Move up in search priority", None))
#endif // QT_CONFIG(tooltip)
        self.pb_up.setText(QCoreApplication.translate("Colls", u"Up", None))
#if QT_CONFIG(tooltip)
        self.pb_down.setToolTip(QCoreApplication.translate("Colls", u"Move down in search priority", None))
#endif // QT_CONFIG(tooltip)
        self.pb_down.setText(QCoreApplication.translate("Colls", u"Down", None))
        self.gb_conn.setTitle(QCoreApplication.translate("Colls", u"Edit", None))
#if QT_CONFIG(tooltip)
        self.pb_open_loc.setToolTip(QCoreApplication.translate("Colls", u"Open", None))
#endif // QT_CONFIG(tooltip)
        self.label.setText(QCoreApplication.translate("Colls", u"Notes", None))
        self.label_3.setText(QCoreApplication.translate("Colls", u"Visible", None))
#if QT_CONFIG(tooltip)
        self.pb_pick_loc.setToolTip(QCoreApplication.translate("Colls", u"Select a location", None))
#endif // QT_CONFIG(tooltip)
        self.pb_pick_loc.setText(QCoreApplication.translate("Colls", u"Location", None))
        self.pb_cancel.setText(QCoreApplication.translate("Colls", u"Reset", None))
        self.pb_save.setText(QCoreApplication.translate("Colls", u"Save", None))
    # retranslateUi

