# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'about.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from  . import icons_rc

class Ui_About(object):
    def setupUi(self, About):
        if not About.objectName():
            About.setObjectName(u"About")
        About.resize(558, 488)
        self.verticalLayout = QVBoxLayout(About)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.groupBox = QGroupBox(About)
        self.groupBox.setObjectName(u"groupBox")
        self.verticalLayout_2 = QVBoxLayout(self.groupBox)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.formLayout = QFormLayout()
        self.formLayout.setObjectName(u"formLayout")
        self.label = QLabel(self.groupBox)
        self.label.setObjectName(u"label")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label)

        self.label_2 = QLabel(self.groupBox)
        self.label_2.setObjectName(u"label_2")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_2)

        self.app_ver = QLineEdit(self.groupBox)
        self.app_ver.setObjectName(u"app_ver")
        self.app_ver.setReadOnly(True)

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.app_ver)

        self.syscoll_ver = QLineEdit(self.groupBox)
        self.syscoll_ver.setObjectName(u"syscoll_ver")
        self.syscoll_ver.setReadOnly(True)

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.syscoll_ver)


        self.verticalLayout_2.addLayout(self.formLayout)


        self.verticalLayout.addWidget(self.groupBox)

        self.groupBox_2 = QGroupBox(About)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.gridLayout = QGridLayout(self.groupBox_2)
        self.gridLayout.setObjectName(u"gridLayout")
        self.label_3 = QLabel(self.groupBox_2)
        self.label_3.setObjectName(u"label_3")

        self.gridLayout.addWidget(self.label_3, 3, 0, 1, 1)

        self.vars_path = QLineEdit(self.groupBox_2)
        self.vars_path.setObjectName(u"vars_path")
        self.vars_path.setReadOnly(True)

        self.gridLayout.addWidget(self.vars_path, 3, 1, 1, 1)

        self.open_colls = QPushButton(self.groupBox_2)
        self.open_colls.setObjectName(u"open_colls")
        icon = QIcon()
        icon.addFile(u":/icons/open.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.open_colls.setIcon(icon)

        self.gridLayout.addWidget(self.open_colls, 1, 3, 1, 1)

        self.label_4 = QLabel(self.groupBox_2)
        self.label_4.setObjectName(u"label_4")

        self.gridLayout.addWidget(self.label_4, 0, 0, 1, 1)

        self.open_srcsys = QPushButton(self.groupBox_2)
        self.open_srcsys.setObjectName(u"open_srcsys")
        self.open_srcsys.setIcon(icon)

        self.gridLayout.addWidget(self.open_srcsys, 0, 3, 1, 1)

        self.colls_path = QLineEdit(self.groupBox_2)
        self.colls_path.setObjectName(u"colls_path")
        self.colls_path.setReadOnly(True)

        self.gridLayout.addWidget(self.colls_path, 1, 1, 1, 1)

        self.srcsys_path = QLineEdit(self.groupBox_2)
        self.srcsys_path.setObjectName(u"srcsys_path")
        self.srcsys_path.setReadOnly(True)

        self.gridLayout.addWidget(self.srcsys_path, 0, 1, 1, 1)

        self.label_6 = QLabel(self.groupBox_2)
        self.label_6.setObjectName(u"label_6")

        self.gridLayout.addWidget(self.label_6, 1, 0, 1, 1)

        self.open_vars = QPushButton(self.groupBox_2)
        self.open_vars.setObjectName(u"open_vars")
        self.open_vars.setIcon(icon)

        self.gridLayout.addWidget(self.open_vars, 3, 3, 1, 1)

        self.label_5 = QLabel(self.groupBox_2)
        self.label_5.setObjectName(u"label_5")

        self.gridLayout.addWidget(self.label_5, 2, 0, 1, 1)

        self.syscoll_path = QLineEdit(self.groupBox_2)
        self.syscoll_path.setObjectName(u"syscoll_path")
        self.syscoll_path.setReadOnly(True)

        self.gridLayout.addWidget(self.syscoll_path, 2, 1, 1, 1)

        self.open_syscoll = QPushButton(self.groupBox_2)
        self.open_syscoll.setObjectName(u"open_syscoll")
        self.open_syscoll.setIcon(icon)

        self.gridLayout.addWidget(self.open_syscoll, 2, 3, 1, 1)

        self.label_9 = QLabel(self.groupBox_2)
        self.label_9.setObjectName(u"label_9")

        self.gridLayout.addWidget(self.label_9, 4, 0, 1, 1)

        self.syslogg_path = QLineEdit(self.groupBox_2)
        self.syslogg_path.setObjectName(u"syslogg_path")
        self.syslogg_path.setReadOnly(True)

        self.gridLayout.addWidget(self.syslogg_path, 4, 1, 1, 1)

        self.open_syslogg = QPushButton(self.groupBox_2)
        self.open_syslogg.setObjectName(u"open_syslogg")
        self.open_syslogg.setIcon(icon)

        self.gridLayout.addWidget(self.open_syslogg, 4, 3, 1, 1)


        self.verticalLayout.addWidget(self.groupBox_2)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalSpacer_1 = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_1)

        self.pb_refresh_ui = QPushButton(About)
        self.pb_refresh_ui.setObjectName(u"pb_refresh_ui")
        icon1 = QIcon()
        icon1.addFile(u":/icons/refresh.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_refresh_ui.setIcon(icon1)

        self.horizontalLayout_2.addWidget(self.pb_refresh_ui)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label_logging = QLabel(About)
        self.label_logging.setObjectName(u"label_logging")

        self.horizontalLayout.addWidget(self.label_logging)

        self.toggle_logging = QPushButton(About)
        self.toggle_logging.setObjectName(u"toggle_logging")

        self.horizontalLayout.addWidget(self.toggle_logging)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.check_updates = QPushButton(About)
        self.check_updates.setObjectName(u"check_updates")

        self.horizontalLayout.addWidget(self.check_updates)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout1 = QHBoxLayout()
        self.horizontalLayout1.setObjectName(u"horizontalLayout1")
        self.clear_log = QPushButton(About)
        self.clear_log.setObjectName(u"clear_log")

        self.horizontalLayout1.addWidget(self.clear_log)

        self.horizontalSpacer_2 = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout1.addItem(self.horizontalSpacer_2)


        self.verticalLayout.addLayout(self.horizontalLayout1)


        self.retranslateUi(About)
        self.check_updates.clicked.connect(About.check_for_updates)
        self.open_vars.clicked.connect(About.open_vars)
        self.open_srcsys.clicked.connect(About.open_srcsys)
        self.open_syscoll.clicked.connect(About.open_syscoll)
        self.open_colls.clicked.connect(About.open_colls)
        self.open_syslogg.clicked.connect(About.open_syslogg)
        self.toggle_logging.clicked.connect(About.runToggleLogging)
        self.pb_refresh_ui.clicked.connect(About.runRefresh)
        self.clear_log.clicked.connect(About.clearlog)

        QMetaObject.connectSlotsByName(About)
    # setupUi

    def retranslateUi(self, About):
        About.setWindowTitle(QCoreApplication.translate("About", u"Form", None))
        self.groupBox.setTitle(QCoreApplication.translate("About", u"Versions", None))
        self.label.setText(QCoreApplication.translate("About", u"Application", None))
        self.label_2.setText(QCoreApplication.translate("About", u"System Collections", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("About", u"Paths", None))
        self.label_3.setText(QCoreApplication.translate("About", u"Variables", None))
#if QT_CONFIG(tooltip)
        self.open_colls.setToolTip(QCoreApplication.translate("About", u"Edit", None))
#endif // QT_CONFIG(tooltip)
        self.label_4.setText(QCoreApplication.translate("About", u"Systems", None))
#if QT_CONFIG(tooltip)
        self.open_srcsys.setToolTip(QCoreApplication.translate("About", u"Open", None))
#endif // QT_CONFIG(tooltip)
        self.label_6.setText(QCoreApplication.translate("About", u"Collections List", None))
#if QT_CONFIG(tooltip)
        self.open_vars.setToolTip(QCoreApplication.translate("About", u"Edit", None))
#endif // QT_CONFIG(tooltip)
        self.label_5.setText(QCoreApplication.translate("About", u"System Collections", None))
#if QT_CONFIG(tooltip)
        self.open_syscoll.setToolTip(QCoreApplication.translate("About", u"Open", None))
#endif // QT_CONFIG(tooltip)
        self.label_9.setText(QCoreApplication.translate("About", u"Detailed Logging", None))
#if QT_CONFIG(tooltip)
        self.open_syslogg.setToolTip(QCoreApplication.translate("About", u"Open", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.pb_refresh_ui.setToolTip(QCoreApplication.translate("About", u"Perform a quick restart of the application", None))
#endif // QT_CONFIG(tooltip)
        self.pb_refresh_ui.setText(QCoreApplication.translate("About", u"Quick Restart", None))
        self.label_logging.setText(QCoreApplication.translate("About", u"Detailed Logging is Currently:", None))
        self.toggle_logging.setText(QCoreApplication.translate("About", u"Updates", None))
        self.check_updates.setText(QCoreApplication.translate("About", u"Check for Updates", None))
        self.clear_log.setText(QCoreApplication.translate("About", u"Clear Log", None))
    # retranslateUi

