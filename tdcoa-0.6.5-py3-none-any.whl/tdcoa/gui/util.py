"GUI Utility classes"
import os
import platform
import subprocess
from pathlib import Path
from typing import Callable, Optional

from PySide2.QtGui import QFont, QValidator
from PySide2.QtWidgets import QLineEdit, QWidget

bold_font = QFont()
bold_font.setBold(True)
strikeout_font = QFont()
strikeout_font.setStrikeOut(True)


class WidgetValidator(QValidator):
	def __init__(self, widget: QWidget, err_fn: Callable[[str], str], *args, **kwargs):
		super().__init__(*args, **kwargs)
		self.widget = widget
		self.err_fn = err_fn
		self._prev_err = ""

	@property
	def validating(self) -> bool:
		return self.widget.isEnabled()

	def show_error(self, msg: str) -> None:
		if msg != self._prev_err:
			self.widget.setStyleSheet("border: 2px solid red" if msg else "")
			self.widget.setStatusTip(msg)
			self._prev_err = msg

	def validate(self, v: str, i: int) -> QValidator.State:
		err = "" if not self.validating else self.err_fn(v)
		self.show_error(err)
		return QValidator.Acceptable if err == "" else QValidator.Intermediate


class NLineEdit(QLineEdit):
	"Nullable LineEdit"
	@property
	def textval(self) -> Optional[str]:
		s = super().text().strip()
		return None if s == "" else s

	@textval.setter
	def textval(self, s: Optional[str]) -> None:
		super().setText("" if s is None else s.strip())


class RLineEdit(QLineEdit):
	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		self.setValidator(WidgetValidator(self, lambda v: "Input required" if v.strip() == "" else ""))

	@property
	def textval(self) -> str:
		return super().text().strip()

	@textval.setter
	def textval(self, s: str) -> None:
		super().setText(s.strip())


def open_folder(folder: Path) -> None:
	if platform.system() == "Windows":
		os.startfile(folder, "explore")
	elif platform.system() == "Darwin":
		subprocess.run(["open", folder])
	else:
		subprocess.run(["xdg-open", folder])


def edit_file(file: Path) -> None:
	if platform.system() == "Windows":
		try:
			os.startfile(file, "edit")
		except OSError:
			subprocess.run(["notepad", file])
	elif platform.system() == "Darwin":
		subprocess.run(["open", file])
	else:
		subprocess.run(["xdg-open", file])
