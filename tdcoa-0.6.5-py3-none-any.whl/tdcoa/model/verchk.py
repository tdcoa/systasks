"application and system collection version informat"
import json
import logging
from dataclasses import dataclass
from datetime import date, timedelta
from functools import cached_property
from pathlib import Path
from typing import Any, Dict, Optional

import requests

from ..util import userdirs
from .githubrel import GithubRelease

logger = logging.getLogger()


@dataclass
class VersionCheck:
	"Version checker for the system collection and the application"
	syscoll_rel: GithubRelease = GithubRelease('tdcoa/systasks', 'systasks.zip')
	appinfo_url: str = "https://raw.githubusercontent.com/tdcoa/systasks/main/.appinfo.json"
	refresh_interval: int = 1
	tracker: Path = userdirs.cache / 'versions.json'

	def update(self) -> None:
		self._meta = dict(
			last_checked=date.today().isoformat(),
			app_ver=self.latest_app_ver,
			syscoll_ver=self.latest_syscoll_ver
		)

		with open(self.tracker, "w") as f:
			json.dump(self._meta, f)

	@cached_property
	def _meta(self) -> Dict[str, Any]:
		if self.tracker.exists():
			with self.tracker.open() as f:
				j = json.load(f)
				j['last_checked'] = date.fromisoformat(j['last_checked'])
				return j
		else:
			return dict(last_checked=date(2000, 1, 1), app_ver=None, syscoll_ver=None)

	@property
	def outdated(self) -> bool:
		"True if last check for versions was done before interval_check period"
		return date.today() - self._meta['last_checked'] >= timedelta(days=self.refresh_interval)

	@property
	def cached_app_ver(self) -> Optional[str]:
		"locally cached application version string"
		return self._meta['app_ver']

	@property
	def cached_syscoll_ver(self) -> Optional[str]:
		"locally cached system collection version string"
		return self._meta['syscoll_ver']

	@cached_property
	def latest_app_ver(self) -> Optional[str]:
		"latest application version string"
		appinfo = requests.get(self.appinfo_url).json()
		logger.debug("fetched latest appinfo.json: %s" % appinfo)
		return appinfo['version']

	@property
	def latest_syscoll_ver(self) -> Optional[str]:
		"latest system collection version string"
		return self.syscoll_rel.version
