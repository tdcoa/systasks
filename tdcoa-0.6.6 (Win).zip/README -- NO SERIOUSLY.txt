
PREREQUISITE: INSTALL PYTHON 3.9.9
=============================================

0) Prereq: Install Python 3.9.9 ( https://www.python.org/downloads/release/python-399/ ) and make sure it's the 
    first Python instance in your PATH.  If you don't like doing this (you use a different version of Python for
    other programs), you can modify the run-script below and add the 3.9.9 path to your PATH environment variable... 
    on Windows it'll usually be at:  C:\Users\<<YOUR_NAME>>\AppData\Local\Programs\Python\Python39\
    If this is your only real use for Python (or your only install of Python), then you're good.

	NOTE: AT THIS TIME, PYTHON 3.10.+ WILL LIKELY ENCOUNTER ERRORS due to a bug in the virtual environment processes.



INSTALL INSTRUCTIONS for tdCOA
=============================================

1) Go to this SharePoint location and download the appropriate tdcoa.zip file (usually the highest for your OS):
    https://teradata.sharepoint.com/teams/SalesTech/COA/Collections/!Application

2) Unzip to a directory to somewhere on your local drive. While it can go on a OneDrive location, it may occasionally 
    error (OneDrive does lock files on upload).  So, it's recommended you either
      a) pause OneDrive while running COA, or
      b) install on a non-OneDrive location, or
      c) set your "output" directory to a non-OneDrive location

3) Double-Click the appropriate "command" file, depending on your OS
   - Windows   = "run-Windows.cmd"
   - Apple Mac = "run-MacOS.command"

4) Wait while the installer does stuff
   - the very first time you run, it will take a few minutes as
     python sets up a virtual environment at that location
     (you'll see a ./env/ folder in that directory)
   - it'll also download and install all dependencies

5) Once the application pops up, you're good-to-go!   
   On Windows, the CMD window will need to stay open, just minimize it 


