"Widget for application logging"
import logging
from typing import Callable

from datetime import datetime

from PySide2 import QtWidgets as Qw

from .logger_ui import Ui_Logger

logger = logging.getLogger(__name__)


class GuiLogger(logging.Handler):
	"funnel log messages to the log window"
	def __init__(self, printer: Callable[[str], None]) -> None:
		super().__init__(logging.WARNING)
		self.setFormatter(logging.Formatter("%(asctime)s %(levelname)s: %(message)s"))
		self.printer = printer

	def emit(self, msg: logging.LogRecord) -> None:
		self.printer(self.format(msg))


class Logger(Qw.QWidget):
	def __init__(self, parent: Qw.QWidget) -> None:
		super().__init__(parent)
		self.ui = Ui_Logger()
		self.ui.setupUi(self)
		self.ui.logger.setVisible(False)

	@property
	def statusbar(self) -> Qw.QStatusBar:
		return self.window().ui.statusbar

	def show_logs(self, visible: bool = True) -> None:
		self.ui.logger.setVisible(visible)
		self.ui.pb_show.setChecked(visible)

	def exception(self, e: Exception) -> None:
		logger.exception(e)
		self.statusbar.showMessage("Unknow error occured; check Logs")
		Qw.QMessageBox.warning(self, "Unknown Error", "Unknow error occured; check Logs")

	def error(self, title: str, msg: str) -> None:
		logger.error(msg)
		self.statusbar.showMessage(msg)
		Qw.QMessageBox.warning(self, title, msg)

	def info(self, msg: str) -> None:
		logger.info(msg)
		self.statusbar.showMessage(msg)

	def log(self, msg: str) -> None:
		"show the message on statusbar and also append to the Logs tab"
		msg = f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} {msg}'
		self.ui.logger.appendPlainText(msg)
		self.statusbar.showMessage(msg)
		self.statusbar.repaint()

	def make_handler(self) -> GuiLogger:
		return GuiLogger(self.log)

	def clear_logs_screen(self):
		self.ui.logger.clear()
