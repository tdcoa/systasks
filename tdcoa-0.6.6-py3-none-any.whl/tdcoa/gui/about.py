"About Widget that displays the application information"
import os
import sys
import subprocess
from datetime import datetime
from PySide2.QtWidgets import QMessageBox, QWidget
import git
import glob
import shutil
from shutil import copyfile

from .. import __version__
from ..maint import refresh, verchk, init_app
from ..model import COLLCONF
from .about_ui import Ui_About
from .util import edit_file, open_folder
from ..util import load_yaml, lru_cache, save_yaml, userdirs


LOCALCONF = userdirs.config / "local_config.yaml"
GIT_PROJECT_URL = 'https://github.com/tdcoa/systasks.git'
class About(QWidget):
	def __init__(self, parent: QWidget) -> None:
		super().__init__(parent)
		self.ui = Ui_About()
		self.ui.setupUi(self)

		self.ui.srcsys_path.setText(str(userdirs.tdsys))
		self.ui.colls_path.setText(str(COLLCONF))
		self.ui.syscoll_path.setText(str(userdirs.systasks))
		self.ui.vars_path.setText(str(userdirs.vars / "default.yaml"))
		self.ui.syslogg_path.setText(str(userdirs.syslogg.absolute()))
		self.update_environment_logging_button_text()
		self.ui.auto_update.setChecked(self.get_auto_update_config())
		self.checkAndPerformVersionUpgrade()

	def show_versions(self) -> None:
		self.ui.app_ver.setText(__version__)
		self.ui.syscoll_ver.setText(verchk.cached_syscoll_ver or 'Unknown')

	def open_vars(self) -> None:
		edit_file(userdirs.vars / 'default.yaml')

	def open_syscoll(self) -> None:
		open_folder(userdirs.systasks)

	def open_colls(self) -> None:
		edit_file(COLLCONF)

	def open_srcsys(self) -> None:
		open_folder(userdirs.tdsys)

	def open_syslogg(self) -> None:
		open_folder(userdirs.syslogg)

	def runRefresh(self) -> None:
		# for local debugging enable the following line and comment next line
		# os.system('cd {} && {} -m tdcoa.gui &'.format(os.getcwd(), sys.executable))
		os.system('tdcoaw &')
		sys.exit()

	def check_for_new_version_availability(self):
		download_path = '/tmp'
		if os.path.exists(download_path + '/systasks'):
			shutil.rmtree(download_path + '/systasks')
		git.Git('/tmp').clone(GIT_PROJECT_URL)
		wheel_file_name = glob.glob(download_path + '/systasks/*whl')
		current_version_number = __version__
		is_new_version_found = False
		new_wheel_path = None
		for ver in wheel_file_name:
			version_num = ver.split('tdcoa-')[-1].split('-')[0]
			if version_num.split('.') > current_version_number.split('.'):
				wheel_dir = str(userdirs.config) + '/dist/' + ver.split('/')[-1]
				if not os.path.exists(str(userdirs.config) + '/dist/'):
					os.mkdir(str(userdirs.config) + '/dist/')
					os.chmod((str(userdirs.config) + '/dist/'), 0o775)
				copyfile(ver, wheel_dir)
				os.chmod(wheel_dir, 0o775)
				current_version_number = version_num
				is_new_version_found = True
				new_wheel_path = wheel_dir
				print(new_wheel_path)
		return is_new_version_found, new_wheel_path

	def check_for_updates(self) -> None:
		# msg = refresh(force_check=True)
		self.checkAndPerformVersionUpgrade()
		# QMessageBox.warning(self, "Check for updates", msg or "All components are up-to-date!")
		self.show_versions()

	def is_logging_enabled(self):
		if os.environ.get('TDCOA_LOGFILE'):
			return True
		return False

	def update_environment_logging_button_text(self):
		text = 'Enabled' if self.is_logging_enabled() else "Disabled"
		color = 'Blue' if self.is_logging_enabled() else "Red"
		self.ui.toggle_logging.setText(str(text))
		#self.ui.toggle_logging.setAutoFillBackground(color)

	def runToggleLogging(self) -> None:
		"""This will alternatively update TDCOA_LOGFILE environment variable
			from None to f'./log/{datetime.strftime(datetime.now(), "%Y%m%d-%H%M%S")}.txt'
			and vice versa
		"""
		disable_logging = False
		if not os.environ.get('TDCOA_LOGFILE'):
			os.environ['TDCOA_LOGFILE'] = f'./log/{datetime.strftime(datetime.now(), "%Y%m%d-%H%M%S")}.txt'
		elif 'TDCOA_LOGFILE' in os.environ:
			os.environ.pop("TDCOA_LOGFILE")
			disable_logging = True
		self.update_environment_logging_button_text()
		from .main import MainWindow
		init_app(MainWindow.log_handler, disable_logging=disable_logging)

	def clearlog(self):
		from .main import MainWindow
		MainWindow.logger.clear_logs_screen()

	def checkAndPerformVersionUpgrade(self):
		if self.ui.auto_update.isChecked():
			is_new_version_found, new_wheel_path = self.check_for_new_version_availability()
			if is_new_version_found:
				ans = QMessageBox.question(self, "New Update Found", f"TDCOA: New Update Found. Do you want to process to install")
				if ans.name == b'Yes':
					p = subprocess.Popen(['pip', 'install', '-U', new_wheel_path], shell=False, stdout=subprocess.PIPE)
					p.wait()
					if p.returncode != 0:
						QMessageBox.warning(self, "Update failed",  "TDCOA: Update failed. We will try in next restart")
						return
					ans2 = QMessageBox.question(self, "Installation completed",
												"TDCOA: New installation completed. Application will now restart. Choose No for manual restart")
					os.remove(new_wheel_path)
					if ans2.name == b'Yes':
						self.runRefresh()
				if ans.name == b'No':
					pass
			else:
				QMessageBox.warning(self, "Check for updates", "All components are up-to-date!")


	def get_auto_update_config(self):
		if LOCALCONF.exists():
			auto_update_value = load_yaml(LOCALCONF)['auto_update']
			return auto_update_value
		else:
			save_yaml({"auto_update": True}, LOCALCONF)
			return True

	def auto_update_changed(self):
		save_yaml({"auto_update": self.ui.auto_update.isChecked()}, LOCALCONF)
