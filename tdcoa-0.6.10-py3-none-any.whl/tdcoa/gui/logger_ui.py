# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'logger.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_Logger(object):
    def setupUi(self, Logger):
        if not Logger.objectName():
            Logger.setObjectName(u"Logger")
        Logger.resize(687, 300)
        self.verticalLayout = QVBoxLayout(Logger)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.pb_show = QCheckBox(Logger)
        self.pb_show.setObjectName(u"pb_show")

        self.horizontalLayout.addWidget(self.pb_show)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.logger = QPlainTextEdit(Logger)
        self.logger.setObjectName(u"logger")
        self.logger.setReadOnly(True)

        self.verticalLayout.addWidget(self.logger)


        self.retranslateUi(Logger)
        self.pb_show.clicked.connect(Logger.show_logs)

        QMetaObject.connectSlotsByName(Logger)
    # setupUi

    def retranslateUi(self, Logger):
        Logger.setWindowTitle(QCoreApplication.translate("Logger", u"Form", None))
        self.pb_show.setText(QCoreApplication.translate("Logger", u"Show log", None))
    # retranslateUi

