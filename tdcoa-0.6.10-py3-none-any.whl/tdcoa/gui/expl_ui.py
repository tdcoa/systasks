# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'expl.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(916, 511)
        self.verticalLayout = QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.description = QTextEdit(Dialog)
        self.description.setObjectName(u"description")
        self.description.setEnabled(False)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.description.sizePolicy().hasHeightForWidth())
        self.description.setSizePolicy(sizePolicy)
        self.description.setReadOnly(True)

        self.verticalLayout.addWidget(self.description)

        self.container = QWidget(Dialog)
        self.container.setObjectName(u"container")
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(10)
        sizePolicy1.setHeightForWidth(self.container.sizePolicy().hasHeightForWidth())
        self.container.setSizePolicy(sizePolicy1)
        self.gridLayout = QGridLayout(self.container)
        self.gridLayout.setObjectName(u"gridLayout")
        self.splitter = QSplitter(self.container)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setOrientation(Qt.Horizontal)
        self.tasklist = QTableWidget(self.splitter)
        if (self.tasklist.columnCount() < 2):
            self.tasklist.setColumnCount(2)
        __qtablewidgetitem = QTableWidgetItem()
        self.tasklist.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tasklist.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        self.tasklist.setObjectName(u"tasklist")
        self.tasklist.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tasklist.setAlternatingRowColors(True)
        self.tasklist.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tasklist.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tasklist.setRowCount(0)
        self.tasklist.setColumnCount(2)
        self.splitter.addWidget(self.tasklist)
        self.tasklist.horizontalHeader().setVisible(True)
        self.tasklist.horizontalHeader().setStretchLastSection(True)
        self.layoutWidget = QWidget(self.splitter)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.verticalLayout_4 = QVBoxLayout(self.layoutWidget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.conn_source = QRadioButton(self.layoutWidget)
        self.buttonGroup_2 = QButtonGroup(Dialog)
        self.buttonGroup_2.setObjectName(u"buttonGroup_2")
        self.buttonGroup_2.addButton(self.conn_source)
        self.conn_source.setObjectName(u"conn_source")
        self.conn_source.setEnabled(False)
        self.conn_source.setCheckable(True)

        self.horizontalLayout_2.addWidget(self.conn_source)

        self.conn_transcend = QRadioButton(self.layoutWidget)
        self.buttonGroup_2.addButton(self.conn_transcend)
        self.conn_transcend.setObjectName(u"conn_transcend")
        self.conn_transcend.setEnabled(False)
        self.conn_transcend.setCheckable(True)

        self.horizontalLayout_2.addWidget(self.conn_transcend)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)

        self.conn_none = QRadioButton(self.layoutWidget)
        self.buttonGroup_2.addButton(self.conn_none)
        self.conn_none.setObjectName(u"conn_none")
        self.conn_none.setEnabled(False)
        self.conn_none.setCheckable(True)

        self.horizontalLayout_2.addWidget(self.conn_none)


        self.verticalLayout_4.addLayout(self.horizontalLayout_2)

        self.task = QStackedWidget(self.layoutWidget)
        self.task.setObjectName(u"task")
        self.export_task = QWidget()
        self.export_task.setObjectName(u"export_task")
        self.verticalLayout_2 = QVBoxLayout(self.export_task)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_2 = QLabel(self.export_task)
        self.label_2.setObjectName(u"label_2")

        self.horizontalLayout_3.addWidget(self.label_2)

        self.exp_sqlfile = QLineEdit(self.export_task)
        self.exp_sqlfile.setObjectName(u"exp_sqlfile")
        self.exp_sqlfile.setReadOnly(True)

        self.horizontalLayout_3.addWidget(self.exp_sqlfile)


        self.verticalLayout_2.addLayout(self.horizontalLayout_3)

        self.exp_sql = QPlainTextEdit(self.export_task)
        self.exp_sql.setObjectName(u"exp_sql")
        font = QFont()
        font.setFamily(u"Courier New")
        self.exp_sql.setFont(font)
        self.exp_sql.setReadOnly(True)

        self.verticalLayout_2.addWidget(self.exp_sql)

        self.formLayout = QFormLayout()
        self.formLayout.setObjectName(u"formLayout")
        self.label_3 = QLabel(self.export_task)
        self.label_3.setObjectName(u"label_3")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label_3)

        self.exp_file = QLineEdit(self.export_task)
        self.exp_file.setObjectName(u"exp_file")
        self.exp_file.setReadOnly(True)

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.exp_file)


        self.verticalLayout_2.addLayout(self.formLayout)

        self.task.addWidget(self.export_task)
        self.ppt_task = QWidget()
        self.ppt_task.setObjectName(u"ppt_task")
        self.formLayout_2 = QFormLayout(self.ppt_task)
        self.formLayout_2.setObjectName(u"formLayout_2")
        self.label_4 = QLabel(self.ppt_task)
        self.label_4.setObjectName(u"label_4")

        self.formLayout_2.setWidget(0, QFormLayout.LabelRole, self.label_4)

        self.ppt_file = QLineEdit(self.ppt_task)
        self.ppt_file.setObjectName(u"ppt_file")
        self.ppt_file.setReadOnly(True)

        self.formLayout_2.setWidget(0, QFormLayout.FieldRole, self.ppt_file)

        self.task.addWidget(self.ppt_task)
        self.execute_task = QWidget()
        self.execute_task.setObjectName(u"execute_task")
        self.verticalLayout_3 = QVBoxLayout(self.execute_task)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label = QLabel(self.execute_task)
        self.label.setObjectName(u"label")

        self.horizontalLayout_5.addWidget(self.label)

        self.exec_sqlfile = QLineEdit(self.execute_task)
        self.exec_sqlfile.setObjectName(u"exec_sqlfile")
        self.exec_sqlfile.setReadOnly(True)

        self.horizontalLayout_5.addWidget(self.exec_sqlfile)


        self.verticalLayout_3.addLayout(self.horizontalLayout_5)

        self.exec_sql = QPlainTextEdit(self.execute_task)
        self.exec_sql.setObjectName(u"exec_sql")
        self.exec_sql.setFont(font)
        self.exec_sql.setReadOnly(True)

        self.verticalLayout_3.addWidget(self.exec_sql)

        self.task.addWidget(self.execute_task)
        self.unkown_task = QWidget()
        self.unkown_task.setObjectName(u"unkown_task")
        self.task.addWidget(self.unkown_task)
        self.import_task = QWidget()
        self.import_task.setObjectName(u"import_task")
        self.formLayout_3 = QFormLayout(self.import_task)
        self.formLayout_3.setObjectName(u"formLayout_3")
        self.label_5 = QLabel(self.import_task)
        self.label_5.setObjectName(u"label_5")

        self.formLayout_3.setWidget(0, QFormLayout.LabelRole, self.label_5)

        self.imp_file = QLineEdit(self.import_task)
        self.imp_file.setObjectName(u"imp_file")
        self.imp_file.setReadOnly(True)

        self.formLayout_3.setWidget(0, QFormLayout.FieldRole, self.imp_file)

        self.label_6 = QLabel(self.import_task)
        self.label_6.setObjectName(u"label_6")

        self.formLayout_3.setWidget(1, QFormLayout.LabelRole, self.label_6)

        self.imp_table = QLineEdit(self.import_task)
        self.imp_table.setObjectName(u"imp_table")
        self.imp_table.setReadOnly(True)

        self.formLayout_3.setWidget(1, QFormLayout.FieldRole, self.imp_table)

        self.task.addWidget(self.import_task)
        self.cmd_task = QWidget()
        self.cmd_task.setObjectName(u"cmd_task")
        self.formLayout_4 = QFormLayout(self.cmd_task)
        self.formLayout_4.setObjectName(u"formLayout_4")
        self.cmd_type = QLabel(self.cmd_task)
        self.cmd_type.setObjectName(u"cmd_type")

        self.formLayout_4.setWidget(0, QFormLayout.LabelRole, self.cmd_type)

        self.cmd_name = QLineEdit(self.cmd_task)
        self.cmd_name.setObjectName(u"cmd_name")
        self.cmd_name.setReadOnly(True)

        self.formLayout_4.setWidget(0, QFormLayout.FieldRole, self.cmd_name)

        self.label_7 = QLabel(self.cmd_task)
        self.label_7.setObjectName(u"label_7")

        self.formLayout_4.setWidget(1, QFormLayout.LabelRole, self.label_7)

        self.cmd_params = QPlainTextEdit(self.cmd_task)
        self.cmd_params.setObjectName(u"cmd_params")
        self.cmd_params.setReadOnly(True)

        self.formLayout_4.setWidget(1, QFormLayout.FieldRole, self.cmd_params)

        self.task.addWidget(self.cmd_task)
        self.copy_task = QWidget()
        self.copy_task.setObjectName(u"copy_task")
        self.verticalLayout_5 = QVBoxLayout(self.copy_task)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_8 = QLabel(self.copy_task)
        self.label_8.setObjectName(u"label_8")

        self.verticalLayout_5.addWidget(self.label_8)

        self.copy_files = QListWidget(self.copy_task)
        self.copy_files.setObjectName(u"copy_files")
        self.copy_files.setAlternatingRowColors(True)

        self.verticalLayout_5.addWidget(self.copy_files)

        self.task.addWidget(self.copy_task)

        self.verticalLayout_4.addWidget(self.task)

        self.splitter.addWidget(self.layoutWidget)

        self.gridLayout.addWidget(self.splitter, 1, 0, 1, 1)


        self.verticalLayout.addWidget(self.container)

        self.buttonBox = QDialogButtonBox(Dialog)
        self.buttonBox.setObjectName(u"buttonBox")
        sizePolicy2 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.buttonBox.sizePolicy().hasHeightForWidth())
        self.buttonBox.setSizePolicy(sizePolicy2)
        self.buttonBox.setOrientation(Qt.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.Close)
        self.buttonBox.setCenterButtons(False)

        self.verticalLayout.addWidget(self.buttonBox)


        self.retranslateUi(Dialog)
        self.buttonBox.clicked.connect(Dialog.accept)
        self.tasklist.itemSelectionChanged.connect(Dialog.showTask)

        self.task.setCurrentIndex(3)


        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        ___qtablewidgetitem = self.tasklist.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Dialog", u"Type", None));
        ___qtablewidgetitem1 = self.tasklist.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Dialog", u"Task", None));
        self.conn_source.setText(QCoreApplication.translate("Dialog", u"Source", None))
        self.conn_transcend.setText(QCoreApplication.translate("Dialog", u"Transcend", None))
        self.conn_none.setText(QCoreApplication.translate("Dialog", u"None", None))
        self.label_2.setText(QCoreApplication.translate("Dialog", u"SQL File", None))
        self.label_3.setText(QCoreApplication.translate("Dialog", u"File", None))
        self.label_4.setText(QCoreApplication.translate("Dialog", u"PPT", None))
        self.label.setText(QCoreApplication.translate("Dialog", u"SQL File", None))
        self.label_5.setText(QCoreApplication.translate("Dialog", u"File", None))
        self.label_6.setText(QCoreApplication.translate("Dialog", u"Table", None))
        self.cmd_type.setText(QCoreApplication.translate("Dialog", u"Proc", None))
        self.label_7.setText(QCoreApplication.translate("Dialog", u"Parameters", None))
        self.label_8.setText(QCoreApplication.translate("Dialog", u"Files", None))
    # retranslateUi

