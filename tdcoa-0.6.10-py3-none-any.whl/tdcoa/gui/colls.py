"Collection Widget"
from pathlib import Path
from typing import Any, Callable, Optional

from PySide2 import QtWidgets as Qw
from PySide2.QtCore import (QAbstractTableModel, QItemSelection, QModelIndex,
							Qt, Signal)

from ..model import Collection, load_collections
from .colls_ui import Ui_Colls
from .util import open_folder, strikeout_font


class TableModel(QAbstractTableModel):
	dirty = Signal(bool)

	def __init__(self):
		super().__init__()
		self.items = load_collections()
		self._is_dirty = False

	@property
	def is_dirty(self) -> bool:
		return self._is_dirty

	@is_dirty.setter
	def is_dirty(self, new_val: bool) -> None:
		if new_val != self._is_dirty:
			self._is_dirty = new_val
			self.dirty.emit(new_val)

	def data(self, index: QModelIndex, role: int) -> Any:
		if role == Qt.DisplayRole:
			if index.column() == 0:
				return self.items[index.row()].name
			if index.column() == 1:
				return str(self.items[index.row()].location.parent)

		if role == Qt.FontRole:
			if not self.items[index.row()].visible:
				return strikeout_font

	def rowCount(self, index: QModelIndex) -> int:
		"number of source systems"
		return len(self.items)

	def columnCount(self, index: QModelIndex) -> int:
		"number of columns"
		return 2

	def headerData(self, section: int, orientation: Qt.Orientation, role: int) -> Any:
		if orientation == Qt.Horizontal:
			if role == Qt.DisplayRole:
				return ["Collection", "Path"][section]

	def swap(self, row1: int, row2: int) -> None:
		"move current row up"
		self.items[row1], self.items[row2] = self.items[row2], self.items[row1]
		self.dataChanged.emit(self.createIndex(row1, 0), self.createIndex(row1, 1))
		self.dataChanged.emit(self.createIndex(row2, 0), self.createIndex(row2, 1))
		self.is_dirty = True

	def update(self, row: int, loc: Path, visible: bool, notes: str) -> None:
		self.items[row].location = loc
		self.items[row].visible = visible
		self.items[row].notes = None if notes.strip() == "" else notes.strip()
		self.dataChanged.emit(self.createIndex(row, 0), self.createIndex(row, 1))
		self.is_dirty = True

	def insert(self, loc: Path) -> None:
		self.beginInsertRows(QModelIndex(), len(self.items), len(self.items))
		self.items.append(Collection(location=loc, notes=None, visible=True))
		self.endInsertRows()
		self.is_dirty = True

	def delete(self, row: int) -> None:
		self.beginRemoveRows(QModelIndex(), row, row)
		del self.items[row]
		self.endRemoveRows()
		self.is_dirty = True

	def save(self) -> None:
		self.items.save()
		self.is_dirty = False

	def reset(self) -> None:
		load_collections.cache_clear()
		self.beginResetModel()
		self.items = load_collections()
		self.endResetModel()
		self.is_dirty = False


class Colls(Qw.QWidget):
	def __init__(self, parent: Qw.QWidget) -> None:
		super().__init__(parent)
		self.ui = Ui_Colls()
		self.ui.setupUi(self)

		self.model = TableModel()
		self.model.dirty.connect(self.enable_save)
		self.selecting = False
		self.changed_slot: Optional[Callable[[], None]] = None

		self.ui.colls_list.setModel(self.model)
		self.ui.colls_list.horizontalHeader().setSectionResizeMode(Qw.QHeaderView.Interactive)
		self.ui.colls_list.selectionModel().selectionChanged.connect(self.set_curr)
		self.ui.colls_list.setCurrentIndex(self.model.index(0, 0))

	def set_curr(self, s: QItemSelection, d: QItemSelection) -> None:
		"change current item"
		self.selecting = True

		coll = self.model.items[s.first().topLeft().row()] if s.count() != 0 else None

		self.ui.pb_up.setEnabled(coll is not None and coll is not self.model.items[0])
		self.ui.pb_down.setEnabled(coll is not None and coll is not self.model.items[-1])

		self.ui.pb_del.setEnabled(coll is not None and not coll.is_system())
		self.ui.pb_pick_loc.setEnabled(coll is not None and not coll.is_system())
		self.ui.pb_open_loc.setEnabled(coll is not None)
		self.ui.local_path.setEnabled(coll is not None)
		self.ui.notes.setEnabled(coll is not None and not coll.is_system())
		self.ui.pb_visible.setEnabled(coll is not None)

		if coll is None:
			self.ui.local_path.setText("")
			self.ui.notes.setPlainText("")
			self.ui.pb_visible.setChecked(False)
		else:
			self.ui.local_path.setText(str(coll.location))
			self.ui.notes.setPlainText(coll.notes)
			self.ui.pb_visible.setChecked(coll.visible)

		self.selecting = False

	def changed(self) -> bool:
		return self.ui.pb_save.isEnabled()

	def move_up(self) -> None:
		"move current item up in the list"
		row = self.ui.colls_list.currentIndex().row()
		self.model.swap(row - 1, row)
		self.ui.colls_list.setCurrentIndex(self.model.index(row - 1, 0))

	def move_down(self) -> None:
		"move current item down in the list"
		row = self.ui.colls_list.currentIndex().row()
		self.model.swap(row, row + 1)
		self.ui.colls_list.setCurrentIndex(self.model.index(row + 1, 0))

	def data_changed(self) -> None:
		"update the model from the new UI data, unless the UI data was changed due to item selection"
		if self.selecting:
			return

		row = self.ui.colls_list.currentIndex().row()
		self.model.update(row, Path(self.ui.local_path.text()), self.ui.pb_visible.isChecked(), self.ui.notes.toPlainText())

	def open_location(self) -> None:
		open_folder(Path(self.ui.local_path.text()))

	def set_location(self) -> None:
		"select a new directory"
		row = self.ui.colls_list.currentIndex().row()
		coll = self.model.items[row]

		new_dir = Qw.QFileDialog.getExistingDirectory(
			self,
			"Select Location",
			str(coll.location),
			Qw.QFileDialog.ShowDirsOnly | Qw.QFileDialog.DontResolveSymlinks
		)
		if not new_dir:
			return

		if (new_loc := Path(new_dir)) == coll.location:
			return

		if any(c for c in self.model.items if c.location == new_loc):
			Qw.QMessageBox.warning(self, "Duplicate collection definition", "Collection already defined; can't add it again")
			return

		self.ui.local_path.setText(new_dir)
		self.data_changed()

	def save_changes(self) -> None:
		"save changes"
		self.model.save()
		if self.changed_slot is not None:
			self.changed_slot()

	def enable_save(self, dirty: bool) -> None:
		self.ui.pb_cancel.setEnabled(dirty)
		self.ui.pb_save.setEnabled(dirty)

	def add_new(self) -> None:
		"Add new item"
		new_dir = Qw.QFileDialog.getExistingDirectory(
			self,
			"Select Location",
			str(Path.cwd()),
			Qw.QFileDialog.ShowDirsOnly | Qw.QFileDialog.DontResolveSymlinks
		)
		if not new_dir:
			return

		new_loc = Path(new_dir)
		if any(c for c in self.model.items if c.location == new_loc):
			Qw.QMessageBox.warning(self, "Duplicate collection definition", "Collection already defined; can't add it again")
			return

		self.model.insert(new_loc)

	def delete_curr(self) -> None:
		"delete currently selected item"
		row = self.ui.colls_list.currentIndex().row()
		ans = Qw.QMessageBox.question(self, "Confirm Removal", f"Remove '{self.model.items[row].name}' (contents will NOT be deleted)?")
		if ans is Qw.QMessageBox.Yes:
			self.model.delete(row)

	def discard_changes(self) -> None:
		"discard changes and go back to list mode"
		if Qw.QMessageBox.question(self, "Confirm Cancel", "Discard all changes?") is Qw.QMessageBox.Yes:
			self.model.reset()
			self.ui.colls_list.setCurrentIndex(self.model.index(0, 0))
