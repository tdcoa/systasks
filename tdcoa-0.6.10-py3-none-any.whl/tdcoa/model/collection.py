"collection model"
from __future__ import annotations
from dataclasses import asdict
from functools import cached_property
from pathlib import Path
from typing import Dict, Iterable, Iterator, Optional, Set, Tuple

from pydantic.dataclasses import dataclass

from ..util import load_yaml, lru_cache, save_yaml, userdirs

COLLCONF = userdirs.config / "collections.yaml"


@dataclass
class Collection:
	"Teradata connection information"
	location: Path
	notes: Optional[str] = None
	visible: bool = True

	@property
	def name(self) -> str:
		"Collection name"
		return self.location.stem

	def is_system(self) -> bool:
		try:
			self.location.relative_to(userdirs.systasks)
			return True
		except ValueError:
			return False

	def __iter__(self) -> Iterator[Path]:
		"iterate tasklists from this collection"
		yield from self.tasklists.values()

	def __hash__(self) -> int:
		return self.location.__hash__()

	def search_by_tags(self, tags: Iterable[str], match_all: bool = True) -> Iterable[Path]:
		"search tasklists that match specified tags. If match_all then ALL must be match; otherwise at least one tag must match"
		tags_set = set(tags)
		match = (lambda t: tags_set <= t) if match_all else (lambda t: bool(tags_set & t))
		return (self.tasklists[p] for p, t in self.tags.items() if match(t))

	@cached_property
	def tasklists(self) -> Dict[str, Path]:
		return {p.stem: p for p in sorted(self.location.glob('*.yaml')) if not p.name.startswith('.')}

	@cached_property
	def _meta(self) -> Tuple[Dict[str, Set[str]], Dict[str, Optional[str]]]:
		"return a tuple of tags dict and docs dict"
		meta = load_yaml(self.location / '.meta.yaml') if (self.location / '.meta.yaml').exists() else {}

		def tags(n: str) -> Set[str]:
			return set(meta['tasklists'][n]['tags']) if 'tasklists' in meta and n in meta['tasklists'] and 'tags' in meta['tasklists'][n] else set()

		def url(n: str) -> Optional[str]:
			return meta['tasklists'][n]['doc'] if 'tasklists' in meta and n in meta['tasklists'] and 'doc' in meta['tasklists'][n] else None

		return ({n: tags(n) for n in self.tasklists}, {n: url(n) for n in self.tasklists})

	@property
	def tags(self) -> Dict[str, Set[str]]:
		"dict containing tasklist name and set of tags"
		return self._meta[0]

	@property
	def docs(self) -> Dict[str, Optional[str]]:
		"dict containing tasklist name and it's documentation URL"
		return self._meta[1]


class Collections(list):
	"All known collections"
	def find(self, location: Path) -> Collection:
		return next(c for c in self if c.location == location)

	def find_first(self, name: str) -> Path:
		"""
		find first tasklist by name. If name is qualified by collection name, then search is limited
		to the specified collection is searched, otherwise all collections are searched.
		ValueError is raised if either collection name or the tasklist name is invalid
		"""
		if '.' not in name:
			p = next((c.tasklists[name] for c in self if name in c.tasklists), None)
			if p is None:
				raise ValueError(f"{name} is not an existing tasklist name")
			return p

		cname, tlname = name.split('.', 1)
		c = next((c for c in self if c.location.stem == cname), None)
		if c is None:
			raise ValueError(f"{cname} is not valid collection name")
		if tlname not in c.tasklists:
			raise ValueError(f"{name} is not an existing tasklist name")
		return c.tasklists[tlname]

	def search_by_tags(self, tags: Iterable[str], match_all: bool = True) -> Iterable[Path]:
		"search tasklists for matching tags"
		return (p for c in self for p in c.search_by_tags(tags, match_all))

	def save(self) -> None:
		save_yaml(dict(collections=[asdict(c) for c in self]), COLLCONF)


def load_collections() -> Collections:
	"load collections"
	if COLLCONF.exists():
		return Collections(Collection(**d) for d in load_yaml(COLLCONF)['collections'])

	colls = Collections(Collection(location=userdirs.systasks / p) for p in ['Metrics', 'Solutions', 'Samples'])
	colls.save()

	return colls
